export interface PageNameState {
    pageName: string;
}