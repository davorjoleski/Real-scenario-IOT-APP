import { createSlice } from "@reduxjs/toolkit"
import { PageNameState } from "./PageNameState";
import { setPageNameReducer } from "./pageNameReducer";

export const initialState: PageNameState = {
    pageName: "listOfSystems"
};

export const pageNameSlice = createSlice({
    name: "pageName",
    initialState,
    reducers: {
        setPageName: setPageNameReducer,
    },
});

export const { setPageName } = pageNameSlice.actions;
export default pageNameSlice.reducer;