import { PayloadAction } from '@reduxjs/toolkit';
import { initialState } from './pageNameSlice';

export const setPageNameReducer = (state = initialState, action: PayloadAction<{ pageName: string; }>) => {
    state.pageName = action.payload.pageName;
};