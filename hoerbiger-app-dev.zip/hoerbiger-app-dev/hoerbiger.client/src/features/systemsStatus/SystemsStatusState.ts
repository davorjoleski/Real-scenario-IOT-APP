import { Device } from "../../model/Device";

export interface SystemsStatusState {
    statuses: Device[];
}