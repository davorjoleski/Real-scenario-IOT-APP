import { PayloadAction } from '@reduxjs/toolkit';
import { initialState } from './SystemsStatusSlice';
import { Device } from '../../model/Device';

export const setSystemsStatusReducer = (state = initialState, action: PayloadAction<{ statuses: Device[]; }>) => {
    state.statuses = action.payload.statuses;
};