import { createSlice } from "@reduxjs/toolkit"
import { SystemsStatusState } from "./SystemsStatusState";
import { setSystemsStatusReducer } from "./systemStatusReducer";

export const initialState: SystemsStatusState = {
    statuses: []
};

export const systemsStatusSlice = createSlice({
    name: "statuses",
    initialState,
    reducers: {
        setSystemsStatus: setSystemsStatusReducer,
    },
});

export const { setSystemsStatus } = systemsStatusSlice.actions;
export default systemsStatusSlice.reducer;