export interface SystemStatus {
    lastMessage: string | null; 
    status: boolean;
};

export interface StatusCacheEntry {
    key: string;
    value: SystemStatus;
}