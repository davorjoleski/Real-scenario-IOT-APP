export interface Device {
    HOEProductID: string;
    status: boolean;
}