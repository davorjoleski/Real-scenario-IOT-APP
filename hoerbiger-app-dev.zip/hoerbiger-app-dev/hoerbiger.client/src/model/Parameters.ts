export interface Parameters {
    CP_VERSION_MINOR: number;
    CP_PARAMETER_COUNT: number;
    CPF_PISTON_O2_POSITION_X: number;
    CPF_PISTON_O2_POSITION_Y: number;
    CPF_PISTON_N2_POSITION_X: number;
    CPF_PISTON_N2_POSITION_Y: number;
    CPF_PISTON_N2_POSITION_Z: number;
    CPF_SETPOINT_PCTOOL_PCO2: number;
    CP_PRESSURE_IN_RANGE_THRESHOLD: number;
    CP_PRESSURE_IN_RANGE_INTER: number;
}