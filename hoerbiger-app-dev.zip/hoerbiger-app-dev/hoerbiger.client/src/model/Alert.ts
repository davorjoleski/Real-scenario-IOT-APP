export interface Alert {

    id: string;
    alertId: string;
    serial_number_system: string;
    serial_number_IOT: string;
    diagnostic_ID: string;
    isRead: boolean;   
    timestamp: string;
}