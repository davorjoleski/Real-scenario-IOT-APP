export interface TsSystem {
    baseVersion: string;
    subVersion: string;
    busCommVersion: string;
    secretVersion: string;
    standaloneVersion: string;
};

export interface TsBoardCU {
    baseVersion: string;
    subVersion: string;
    productionWeek: number;
    productionYear: number;
    manufacturerName: string;
};
export interface TsBoardHMI {
    baseVersion: string;
    subVersion: string;
    productionWeek: number;
    productionYear: number;
    manufacturerName: string;
};
export interface SystemInfo {
    tsSystem: TsSystem;
    tsBoardCU: TsBoardCU;
    tsBoardHMI: TsBoardHMI;
}
