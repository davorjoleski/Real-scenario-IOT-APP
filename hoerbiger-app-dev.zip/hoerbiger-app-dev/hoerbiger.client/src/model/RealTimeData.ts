export interface RealTimePeriodic {
    InputO2_P1_bar: number;
    InputN2_P1_bar: number;
    OutputO2_P2_bar: number;
    OutputN2_P2_bar: number;
    FLOW_O2: number;
    FLOW_N2: number;
    Setpoint_Percent_O2: number;
    Current_Val_Percent_O2: number;
    State: number;
}
export interface RealTimePeriodicData{
    Realtime_Periodic_Data: RealTimePeriodic;
}


