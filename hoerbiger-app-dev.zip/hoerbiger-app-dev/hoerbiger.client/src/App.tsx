import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import ListOfSystemsView from "./views/ListOfSystemsView.tsx";
import DeviceView from './views/DeviceView.tsx';
import { useSelector } from 'react-redux';
import { RootState } from './main'

function App() {
    const page = useSelector((state: RootState) => state.pageName.pageName);
    const statuses = useSelector((state: RootState) => state.systemsStatus.statuses);

    console.log("page ", page);
    console.log("status ", statuses);

    return (
        <Router>
            <Routes>
                <Route path="/" element={<ListOfSystemsView />} />
                <Route path="/:deviceId" element={<DeviceView />} />
                {/*<Route path="/:deviceId/systemInfo" element={<SystemInfoView />} />
                <Route path="/:deviceId/realtimeInfo" element={<RealtimeInfoView />} />
                <Route path="/:deviceId/dataArchive" element={<DataArchiveView />} />
                <Route path="/:deviceId/parameters" element={<ParametersView />} />
                <Route path="/:deviceId/capture" element={<CaptureView />} />
                <Route path="/:deviceId/diagnostic" element={<DiagnosticView />} />
                <Route path="/:deviceId/alerts" element={<AlertsView />} />*/}
                    </Routes>
                </Router>
         
    )
}

export default App;