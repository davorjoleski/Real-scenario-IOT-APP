import { useNavigate, useParams } from "react-router-dom";
import { CSSProperties, useEffect, useState } from "react";
import { setPageName } from '../features/pageName/pageNameSlice';
import { useDispatch } from "react-redux";
import { ClipLoader } from "react-spinners";
import HeaderBar from "./HeaderBar";
import { ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import { Parameters } from "../model/Parameters";
import { Slide, toast } from "react-toastify";

const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
};
function ParametersComponent() {

    const [parameters, setParameters] = useState<Parameters | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const { deviceId } = useParams<{ deviceId: string }>();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const notifyError = () => toast.error(error, {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Slide,
    });

   
    useEffect(() => {
        const fetchParameters = async () => {
            try {
                setLoading(true);
                setError(null);
                const response = await fetch(`/api/params/${deviceId}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch: ${JSON.parse(await response.text()).message}`);
                }
                const data: Parameters = await response.json();
                setParameters(data);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setLoading(false);
            }
        };

        fetchParameters();
    }, []);



    const goToPage = (pageName: string) => {
        dispatch(setPageName({ pageName: pageName }));
        if (pageName == "listOfSystems") {
            navigate("/");
        }
        else 
            navigate(`/${deviceId}`);
    }

    if (error) {
        notifyError();
        setError(null)
    }


    return (
        <div className="bg-white border border-black-200 p-[32px] w-full shadow-md">
            <div className="flex justify-between">
                <HeaderBar headerText={`Parameters - ${deviceId}`} />
                <ArrowTopRightOnSquareIcon className="w-5 mt-[-20px]" onClick={() => goToPage("parameters")} />
            </div>
            {loading ? (<ClipLoader cssOverride={override} />):(
            <section className="pt-5">
                    <div className="border border-black-300 p-2">
                    {parameters && (() => {
                        const entries = Object.entries(parameters);
                        const firstHalf = entries.slice(0, 5);
                        const secondHalf = entries.slice(5);

                        return (
                            <>
                                <div className="flex justify-between pb-4">
                                    {firstHalf.map(([key, value], index) => (
                                        <div key={index} className="flex flex-col w-[90px] break-words">
                                            <div className="text-[10px]">
                                                {key.split('_').map((part, i) => (
                                                    <span key={i}>{part} </span>
                                                ))}
                                            </div>
                                            <div className="text-[24px]">{value}</div>
                                        </div>
                                    ))}
                                </div>
                                <div className="flex justify-between">
                                    {secondHalf.map(([key, value], index) => (
                                        <div key={index} className="flex flex-col w-[90px] break-words">
                                            <div className="text-[10px]">
                                                {key.split('_').map((part, i) => (
                                                    <span key={i}>{part} </span>
                                                ))}
                                            </div>
                                            <div className="text-[24px]">{value}</div>
                                        </div>
                                    ))}
                                </div>
                            </>
                        );
                    })()}
                    
                </div>
            </section>)}
        </div>
    );
}

export default ParametersComponent;