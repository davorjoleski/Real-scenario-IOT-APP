import { HeaderBarProps } from "./props/HeaderBarProps.ts";

function HeaderBar({ headerText }: HeaderBarProps) {
    return (
       <div className="w-full flex items-center ">
          <span className="text-black noto-sans-semibold text-[20px]">
              {headerText}
          </span>
      </div>
  );
}

export default HeaderBar;