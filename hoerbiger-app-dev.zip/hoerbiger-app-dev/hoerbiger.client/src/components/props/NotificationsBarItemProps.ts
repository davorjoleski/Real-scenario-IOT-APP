export interface NotificationsBarItemProps {
    Serial_number_system: string;
    Serial_number_iot: string;
    Diagnostic_id: string;
    time: string;
}