
export interface HeaderBarProps {
    headerText : string
}