import { Device } from "../../model/Device";

export interface TableProps {
    headers?: string[];
    values: Device[];
    addButton?: boolean;
}