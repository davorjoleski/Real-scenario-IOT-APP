import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { ResponsiveContainer, LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Line } from "recharts";
import HeaderBar from "../components/HeaderBar";
interface ChartData {
    time: Date;
    InputO2_P1_bar: number | null;
    InputN2_P1_bar: number | null;
    OutputO2_P2_bar: number | null;
    OutputN2_P2_bar: number | null;
    FLOW_O2: number | null;
    FLOW_N2: number | null;
    Setpoint_Percent_O2: number | null;
    Current_Val_Percent_O2: number | null;
    State: string | null;
}
function CustomLineChart() {
    const { deviceId } = useParams<{ deviceId: string }>();
    const [selectedData, setSelectedData] = useState<ChartData[]>([]);
    const [selectedOption, setSelectedOption] = useState<string>("min");
    const [selectedTimestamp, setSelectedTimestamp] = useState<string>("15m");
    const [activeTab, setActiveTab] = useState(1);
    const [showInputPressureO2, setShowInputPressureO2] = useState(true);
    const [showInputPressureN2, setShowInputPressureN2] = useState(true);
    const [showOutputPressureO2, setShowOutputPressureO2] = useState(true);
    const [showOutputPressureN2, setShowOutputPressureN2] = useState(true);
    const [showFlowO2, setShowFlowO2] = useState(false);
    const [showFlowN2, setShowFlowN2] = useState(false);
    const [showSetpointO2, setShowSetpointO2] = useState(true);
    const [showCurrentValueO2, setShowCurrentValueO2] = useState(true);
    const [showState, setShowState] = useState(true);
    const [fields, setFields] = useState<string[]>(['InputO2_P1_bar', 'InputN2_P1_bar', 'OutputO2_P2_bar', 'OutputN2_P2_bar', 'Setpoint_Percent_O2', 'Current_Val_Percent_O2', 'State']);
    const [startRange, setStartRange] = useState<Date>(() => {
        return minutesAgo(15);
    });
    const [stopRange, setStopRange] = useState<Date>(new Date(Date.now()));

    const fetchDataPoints = async (fields: string[], option: string, timestamp: string, startRange: Date, stopRange: Date) => {
        setSelectedData([]);
        const requestBody = {
            deviceId: deviceId,
            timestamp: timestamp,
            fields: fields,
            function: option,
            startRange: startRange,
            stopRange: stopRange
        };
        try {
            const response = await fetch("api/realtimedata/GetAll", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(requestBody),
            });
            if (response.ok) {
                const rawData: ChartData[] = await response.json();

                setSelectedData(rawData);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    useEffect(() => {
        fetchDataPoints(fields, selectedOption, selectedTimestamp, startRange, stopRange);
    }, [fields, selectedOption, selectedTimestamp, startRange, stopRange]);

    const formatDate = (date: Date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');

        return `${year}-${month}-${day}T${hours}:${minutes}`
    }
    const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedOption(event.target.value);
    };
    const handleSelectChangeTime = (event: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedTimestamp(event.target.value);
        const minutes = parseInt(event.target.value.split("m")[0])
        setStartRange(minutesAgo(minutes))
        setStopRange(new Date(Date.now()))
    };
    const handleSelectStartRange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setStartRange(new Date(event.target.value));
    };
    const handleSelectStopRange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setStopRange(new Date(event.target.value));
    };
    const handleTabChange = (tabNumber: number) => {
        if (activeTab !== tabNumber) {
            setActiveTab(tabNumber);
        }
        if (activeTab == 1) {
            setFields(['FLOW_O2', 'FLOW_N2']);
            setShowInputPressureN2(false);
            setShowInputPressureO2(false);
            setShowOutputPressureO2(false);
            setShowOutputPressureN2(false);
            setShowSetpointO2(false);
            setShowCurrentValueO2(false);
            setShowState(false);
            setShowFlowN2(true);
            setShowFlowO2(true);
        }
        else {
            setFields(['InputO2_P1_bar', 'InputN2_P1_bar', 'OutputO2_P2_bar', 'OutputN2_P2_bar', 'Setpoint_Percent_O2', 'Current_Val_Percent_O2', 'State']);
            setShowInputPressureN2(true);
            setShowInputPressureO2(true);
            setShowOutputPressureO2(true);
            setShowOutputPressureN2(true);
            setShowSetpointO2(true);
            setShowCurrentValueO2(true);
            setShowState(true);
            setShowFlowN2(false);
            setShowFlowO2(false);
        }
    };
    const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = event.target;

        setFields(prevFields =>
            checked
                ? [...prevFields, name]
                : prevFields.filter(field => field !== name)
        );

        switch (name) {
            case "InputO2_P1_bar":
                setShowInputPressureO2(checked);
                break;
            case "InputN2_P1_bar":
                setShowInputPressureN2(checked);
                break;
            case "OutputO2_P2_bar":
                setShowOutputPressureO2(checked);
                break;
            case "OutputN2_P2_bar":
                setShowOutputPressureN2(checked);
                break;
            case "FLOW_O2":
                setShowFlowO2(checked);
                break;
            case "FLOW_N2":
                setShowFlowN2(checked);
                break;
            case "Setpoint_Percent_O2":
                setShowSetpointO2(checked);
                break;
            case "Current_Val_Percent_O2":
                setShowCurrentValueO2(checked);
                break;
            case "State":
                setShowState(checked);
                break;
            default:
                break;
        }
    };

    return (
        <div className="bg-white border border-black-200 p-[32px] min-h-[80vh] shadow-md">
            <HeaderBar headerText={`Device archived data - ${deviceId}`} />
            <div className="flex mt-9 justify-between">
                <div className="w-[193px] flex-shrink-0">
                    <div role="tablist" className="tabs tabs-lifted">
                        <a
                            onClick={() => handleTabChange(1)}
                            role="tab"
                            className={`noto-sans-bold h-10  tab  ${activeTab === 1 ? "tab-active " : ""}`}
                        >
                            Table 1
                        </a>
                        <a
                            onClick={() => handleTabChange(2)}
                            role="tab"
                            className={`noto-sans-bold h-10 tab  ${activeTab === 2 ? "tab-active" : ""}`}
                        >
                            Table 2
                        </a>
                    </div>
                    {activeTab == 1 ?
                        <div className="flex flex-col h-2/3 text-xs noto-sans-regular">
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label >Input Pressure O2</label>
                                <input
                                    type="checkbox"
                                    name="InputO2_P1_bar"
                                    checked={showInputPressureO2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Input Pressure N2</label>
                                <input
                                    type="checkbox"
                                    name="InputN2_P1_bar"
                                    checked={showInputPressureN2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Output Pressure O2</label>
                                <input
                                    type="checkbox"
                                    name="OutputO2_P2_bar"
                                    checked={showOutputPressureO2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Output Pressure N2</label>
                                <input
                                    type="checkbox"
                                    name="OutputN2_P2_bar"
                                    checked={showOutputPressureN2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Setpoint %O2</label>
                                <input
                                    type="checkbox"
                                    name="Setpoint_Percent_O2"
                                    checked={showSetpointO2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Current Value %O2</label>
                                <input
                                    type="checkbox"
                                    name="Current_Val_Percent_O2"
                                    checked={showCurrentValueO2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>State</label>
                                <input
                                    type="checkbox"
                                    name="State"
                                    checked={showState}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                        </div>
                        :
                        <div className="flex flex-col text-xs noto-sans-regular">
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Flow O2</label>
                                <input
                                    type="checkbox"
                                    name="FLOW_O2"
                                    checked={showFlowO2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                            <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                <label>Flow N2</label>
                                <input
                                    type="checkbox"
                                    name="FLOW_N2"
                                    checked={showFlowN2}
                                    onChange={handleCheckboxChange}
                                />
                            </div>
                        </div>}
                </div>
                <div className="w-full pl-7">
                    <div className="pl-7">
                        <div className="flex flex-wrap gap-[8px]">
                            <div>
                                <label className="text-xs noto-sans-semibold">Select Data Type: </label>
                                <select onChange={handleSelectChange} value={selectedOption} className="text-xs p-1 border border-black-300">
                                    <option value="min">Min</option>
                                    <option value="max">Max</option>
                                    <option value="mean">Avg</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs noto-sans-semibold">Select time period: </label>
                                <select onChange={handleSelectChangeTime} value={selectedTimestamp} className="text-xs p-1 border border-black-300">
                                    <option value="15m">Last 15 min</option>
                                    <option value="30m">Last 30 min</option>
                                    <option value="60m">Last hour</option>
                                    <option value="1440m">last 24 hours</option>
                                    <option value="10080m">Last week</option>
                                    <option value="43800m">Last month</option>

                                </select>
                            </div>
                            <div>
                                <label className="text-xs noto-sans-semibold">Start range: </label>
                                <input
                                    type="datetime-local"
                                    name="start"
                                    onChange={handleSelectStartRange}
                                    value={formatDate(startRange)}
                                    className="text-xs p-1 border border-black-300 w-[133px]"
                                />
                            </div>
                            <div>
                                <label className="text-xs noto-sans-semibold">Stop range: </label>
                                <input
                                    type="datetime-local"
                                    name="stop"
                                    onChange={handleSelectStopRange}
                                    value={formatDate(stopRange)}
                                    className="text-xs p-1 border border-black-300 w-[133px]"
                                />
                            </div>
                        </div>
                    </div>
                    <div className=" pt-3 w-full ">
                        <ResponsiveContainer width="100%" height={350}>
                            <LineChart data={selectedData} margin={{  bottom: 50 }} >
                                <CartesianGrid strokeDasharray="3 3" />
                                {/*<XAxis dataKey="time" tickFormatter={() => ""} />*/}
                                <XAxis dataKey="time" tickFormatter={(time) => {
                                    const datetime = new Date(time)
                                    const minutes = parseInt(selectedTimestamp.split("m")[0])
                                    return minutes > 1440 ? datetime.toLocaleDateString() : datetime.toLocaleTimeString()
                                }}
                                    tick={{ fontSize: 12, angle: -45, textAnchor: "end", dy: 10 }} />
                                <YAxis />
                                <Tooltip />
                                <Legend layout="horizontal" align="center" verticalAlign="top" wrapperStyle={{ fontSize: "12px", paddingBottom: 20 }} />
                                {showInputPressureO2 && <Line type="monotone" dataKey="InputO2_P1_bar" dot={false} stroke="#03a1fc" strokeWidth={1} isAnimationActive={false} />}
                                {showInputPressureN2 && < Line type="monotone" dataKey="InputN2_P1_bar" dot={false} stroke="#032cfc" strokeWidth={1} isAnimationActive={false} />}
                                {showOutputPressureO2 && <Line type="monotone" dataKey="OutputO2_P2_bar" dot={false} stroke="#ad03fc" strokeWidth={1} isAnimationActive={false} />}
                                {showOutputPressureN2 && <Line type="monotone" dataKey="OutputN2_P2_bar" dot={false} stroke="#03fcdf" strokeWidth={1} isAnimationActive={false} />}
                                {showFlowO2 && <Line type="monotone" dataKey="FLOW_O2" stroke="#02a63b" dot={false} strokeWidth={1} isAnimationActive={false} />}
                                {showFlowN2 && <Line type="monotone" dataKey="FLOW_N2" stroke="#dffc03" dot={false} strokeWidth={1} isAnimationActive={false} />}
                                {showSetpointO2 && <Line type="monotone" dataKey="Setpoint_Percent_O2" dot={false} stroke="#fcba03" strokeWidth={1} isAnimationActive={false} />}
                                {showCurrentValueO2 && <Line type="monotone" dataKey="Current_Val_Percent_O2" dot={false} stroke="#fc0703" strokeWidth={1} isAnimationActive={false} />}
                                {showState && <Line type="monotone" dataKey="State" stroke="#e60292" dot={false} strokeWidth={1} isAnimationActive={false} />}
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default CustomLineChart;

const minutesAgo = (minutes: number) => {
    const date = new Date(Date.now());
    const diff = date.getMinutes() - minutes;
    date.setMinutes(diff);
    return date;
}
