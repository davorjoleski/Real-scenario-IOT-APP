import { useNavigate, useParams } from "react-router-dom";
import HeaderBar from "./HeaderBar";
import { CSSProperties, useEffect, useState } from "react";
import { RealTimePeriodicData } from "../model/RealTimeData";
import { ClipLoader } from "react-spinners";
import { ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import { setPageName } from '../features/pageName/pageNameSlice';
import { useDispatch } from "react-redux";


const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
};
function RealtimeDataComponent() {

    const { deviceId } = useParams<{ deviceId: string }>();
    const [data, setData] = useState<RealTimePeriodicData | null>(null);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const goToPage = (pageName: string) => {
        dispatch(setPageName({ pageName: pageName }));
        if (pageName == "listOfSystems") {
            navigate("/");
        }
        else //navigate(`/${deviceId}/${pageName}`);
            navigate(`/${deviceId}`);
    }

    useEffect(() => {
        const websocket = new WebSocket(`ws/${deviceId}`);

        websocket.onmessage = (event: MessageEvent) => {
            console.log("Received:", event.data);
            const json = JSON.parse(event.data);
            setData(json);

            console.log(json)
        };

        websocket.onerror = (event) => {
            console.error("WebSocket error:", event);
        };

        websocket.onclose = () => {
            console.log("WebSocket connection closed");
        };

        return () => {
            websocket.close();
        };
    }, []);

    return (
        <div className="bg-white border border-black-200 p-[32px] w-full shadow-md">
            <div className="flex justify-between">
                <HeaderBar headerText={`Device real data - ${deviceId}`} />
                <ArrowTopRightOnSquareIcon className="w-5 mt-[-20px]" onClick={() => goToPage("realtimeInfo")} />
            </div>
            {data==null ? (<ClipLoader cssOverride={override} />): (
            <section className="pt-5">
                <div>
                    {data ?
                        (<div className="w-full noto-sans-regular">

                            <div className="flex justify-between border border-black-300 py-4 px-7">
                                <div className="flex flex-col ">
                                    <span className="text-[10px]">INPUT N2 P1 BAR</span>
                                    <span className="text-[24px]">{data.Realtime_Periodic_Data.InputN2_P1_bar}</span>
                                </div>
                                <div className="flex flex-col ">
                                    <td className="text-[10px]">INPUT O2 P1 BAR</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.InputO2_P1_bar}</td>
                                </div>
                                <div className="flex flex-col ">
                                    <td className="text-[10px]">OUTPUT N2 P2 BAR</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.OutputN2_P2_bar}</td>
                                </div>
                                <div className="flex flex-col ">

                                    <td className="text-[10px]">OUTPUT O2 P2 BAR</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.OutputO2_P2_bar}</td>
                                </div>
                                <div className="flex flex-col ">

                                    <td className="text-[10px]">FLOW N2</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.FLOW_N2}</td>
                                </div>
                                <div className="flex flex-col ">
                                    <td className="text-[10px]">FLOW O2</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.FLOW_O2}</td>
                                </div>
                                <div className="flex flex-col ">

                                    <td className="text-[10px]">SETPOINT PERCENT O2</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.Setpoint_Percent_O2}</td>
                                </div>
                                <div className="flex flex-col ">

                                    <td className="text-[10px]">CURRENT VAL PERCENT O2</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.Current_Val_Percent_O2}</td>
                                </div>
                                <div className="flex flex-col ">
                                    <td className="text-[10px]">STATE</td>
                                    <td className="text-[24px]">{data.Realtime_Periodic_Data.State}</td>
                                </div>
                            </div>

                        </div>
                        ) : (<div>No real time data sent</div>)}
                </div>
            </section>) }
        </div>
    );
}

export default RealtimeDataComponent;