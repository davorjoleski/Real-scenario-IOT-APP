import { useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import HeaderBar from "./HeaderBar";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import { setPageName } from '../features/pageName/pageNameSlice';
import { useDispatch } from "react-redux";

interface ChartData {
    time: Date;
    InputO2_P1_bar: number | null;
    InputN2_P1_bar: number | null;
    OutputO2_P2_bar: number | null;
    OutputN2_P2_bar: number | null;
    FLOW_O2: number | null;
    FLOW_N2: number | null;
    Setpoint_Percent_O2: number | null;
    Current_Val_Percent_O2: number | null;
    State: string | null;
}
function DataArchiveComponent() {

    const { deviceId } = useParams<{ deviceId: string }>();
    const [selectedData, setSelectedData] = useState<ChartData[]>([]);
    const [selectedOption, setSelectedOption] = useState<string>("min");
    const [selectedTimestamp, setSelectedTimestamp] = useState<string>("15m");
    const [showInputPressureO2, setShowInputPressureO2] = useState(true);
    const [showInputPressureN2, setShowInputPressureN2] = useState(true);
    const [showOutputPressureO2, setShowOutputPressureO2] = useState(true);
    const [showOutputPressureN2, setShowOutputPressureN2] = useState(true);
    const [showFlowO2, setShowFlowO2] = useState(false);
    const [showFlowN2, setShowFlowN2] = useState(false);
    const [showSetpointO2, setShowSetpointO2] = useState(true);
    const [showCurrentValueO2, setShowCurrentValueO2] = useState(true);
    const [showState, setShowState] = useState(true);
    const [fields, setFields] = useState<string[]>(['InputO2_P1_bar', 'InputN2_P1_bar', 'OutputO2_P2_bar', 'OutputN2_P2_bar', 'Setpoint_Percent_O2', 'Current_Val_Percent_O2', 'State']);
    const [startRange, setStartRange] = useState<Date>(() => {
        return minutesAgo(15);
    });
    const [stopRange, setStopRange] = useState<Date>(new Date(Date.now()));
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const goToPage = (pageName: string) => {
        dispatch(setPageName({ pageName: pageName }));
        if (pageName == "listOfSystems") {
            navigate("/");
        }
        else 
            navigate(`/${deviceId}`);
    }

    const fetchDataPoints = async (fields: string[], option: string, timestamp: string, startRange: Date, stopRange: Date) => {
        setSelectedData([]);
        const requestBody = {
            deviceId: deviceId,
            timestamp: timestamp,
            fields: fields,
            function: option,
            startRange: startRange,
            stopRange: stopRange
        };
        try {
            const response = await fetch("api/realtimedata/GetAll", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(requestBody),
            });
            if (response.ok) {
                const rawData: ChartData[] = await response.json();

                setSelectedData(rawData);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    useEffect(() => {
        fetchDataPoints(fields, selectedOption, selectedTimestamp, startRange, stopRange);
    }, [fields, selectedOption, selectedTimestamp, startRange, stopRange]);

    return (
        <div className="bg-white border border-black-200 p-[32px]  shadow-md">
            <div className="flex justify-between  pb-5">
                <div className="flex">
                    <HeaderBar headerText={`Device archived data - ${deviceId}`} />
                    <div className="flex pl-2 text-xs w-[80px] flex-shrink-0 noto-sans-regular items-center"> - Last 15 min</div>
                </div>
                <ArrowTopRightOnSquareIcon className="w-5 mt-[-20px]" onClick={() => goToPage("dataArchive")} />
            </div>
            <div className="w-full ">

                <ResponsiveContainer width="100%" height={350}>
                    <LineChart data={selectedData} >
                        <CartesianGrid strokeDasharray="3 3" />
                        {/*<XAxis dataKey="time" tickFormatter={() => ""} />*/}
                        <XAxis dataKey="time" tickFormatter={(time) => {
                            const datetime = new Date(time)
                            const minutes = parseInt(selectedTimestamp.split("m")[0])
                            return minutes > 1440 ? datetime.toLocaleDateString() : datetime.toLocaleTimeString()
                        }}
                            tick={{ fontSize: 12, angle: -45, textAnchor: "end", dy: 10 }} />
                        <YAxis />
                        <Tooltip />
                        {showInputPressureO2 && <Line type="monotone" dataKey="InputO2_P1_bar" dot={false} stroke="#03a1fc" strokeWidth={1} isAnimationActive={false} />}
                        {showInputPressureN2 && < Line type="monotone" dataKey="InputN2_P1_bar" dot={false} stroke="#032cfc" strokeWidth={1} isAnimationActive={false} />}
                        {showOutputPressureO2 && <Line type="monotone" dataKey="OutputO2_P2_bar" dot={false} stroke="#ad03fc" strokeWidth={1} isAnimationActive={false} />}
                        {showOutputPressureN2 && <Line type="monotone" dataKey="OutputN2_P2_bar" dot={false} stroke="#03fcdf" strokeWidth={1} isAnimationActive={false} />}
                        {showFlowO2 && <Line type="monotone" dataKey="FLOW_O2" stroke="#02a63b" dot={false} strokeWidth={1} isAnimationActive={false} />}
                        {showFlowN2 && <Line type="monotone" dataKey="FLOW_N2" stroke="#dffc03" dot={false} strokeWidth={1} isAnimationActive={false} />}
                        {showSetpointO2 && <Line type="monotone" dataKey="Setpoint_Percent_O2" dot={false} stroke="#fcba03" strokeWidth={1} isAnimationActive={false} />}
                        {showCurrentValueO2 && <Line type="monotone" dataKey="Current_Val_Percent_O2" dot={false} stroke="#fc0703" strokeWidth={1} isAnimationActive={false} />}
                        {showState && <Line type="monotone" dataKey="State" stroke="#e60292" dot={false} strokeWidth={1} isAnimationActive={false} />}
                        <Legend layout="horizontal" align="center" verticalAlign="bottom" wrapperStyle={{ fontSize: "12px", paddingTop: 60 }} />

                    </LineChart>
                </ResponsiveContainer>
            </div>
        </div>
    );

}

export default DataArchiveComponent;

const minutesAgo = (minutes: number) => {
    const date = new Date(Date.now());
    const diff = date.getMinutes() - minutes;
    date.setMinutes(diff);
    return date;
}
