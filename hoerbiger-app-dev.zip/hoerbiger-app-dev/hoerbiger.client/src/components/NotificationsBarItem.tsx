import { AlertProps } from "../views/AlertsView";

function NotificationsBarItem({ id, alertId, systemSerial, iotSerial, diagnosticId, time, isRead, timeAgo }: AlertProps) {

    return (
        <div className="w-full noto-sans-medium text-xs pt-3" >
            <div className="flex justify-between pb-1">
                <div className="text-sm noto-sans-bold">Alert - {alertId}</div>
                <div className="text-[#525252] text-xs">{timeAgo}
                    {!isRead && <span className="ml-2 relative inline-flex size-2 rounded-full bg-[#075289]"></span>}
                </div>
            </div>
            <div className="text-[#737373] " >
                <div>Serial number system: {systemSerial}</div>
                <div>Serial number iot: {iotSerial}</div>
                <div>Diagnostic id: {diagnosticId}</div>
            </div>
        </div>
    );
}

export default NotificationsBarItem;