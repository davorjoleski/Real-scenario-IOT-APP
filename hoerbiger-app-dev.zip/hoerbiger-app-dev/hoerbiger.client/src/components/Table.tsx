import { useDispatch } from "react-redux";
import { TableProps } from "./props/TableProps.ts";
import { useNavigate } from "react-router-dom";
import { setPageName } from "../features/pageName/pageNameSlice";
import HeaderBar from "./HeaderBar.tsx";

function Table({ values }: TableProps) {

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const goToPage = (deviceName: string, status: boolean) => {
        if (status) {
            dispatch(setPageName({ pageName: "systemInfo" }));
        }
        else {
            dispatch(setPageName({ pageName: "dataArchive" }));
        }
        navigate(`/${deviceName}`);
    }

    return (
        <div className={`border border-gray-200 shadow-md m-[60px] min-h-[168px] p-[32px] overflow-auto relative bg-white ${values.length > 0 ? 'min-h-[348px]' : ''}`}>
            <div className="ml-2 mb-7">
                <HeaderBar headerText={`List of all systems`} />
            </div>
            {values.length === 0 ? (
                <div>
                    <p className="noto-sans-bold py-6 px-2 h-16 text-sm">No systems registered</p>
                </div>
            ) : (
                <table className="w-full h-auto overflow-auto border-collapse bg-white text-left text-sm text-gray-500">
                    <thead className="bg-white">
                        <tr className="h-12">
                            <th scope="col" className="noto-sans-bold px-2 py-3 text-sm text-black">System name</th>
                            <th scope="col" className="noto-sans-bold px-2 py-3 text-sm text-black">State</th>
                            <th scope="col" className="noto-sans-bold px-2 py-3 text-sm text-black"></th>
                        </tr>
                    </thead>

                    <tbody className="divide-y divide-gray-100 border-t border-gray-100 h-full">
                        {
                            values.map((device, index) => (
                                <tr key={index} className="h-[52px]">
                                    <td className="px-2 h-12">
                                        <div className="text-sm noto-sans-regular text-gray-700">{device.HOEProductID}</div>
                                    </td>
                                    <td className="px-2 h-12">
                                        {device.status ? (
                                            <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2 py-1 text-xs noto-sans-regular text-green-600">
                                                <span className="h-1.5 w-1.5 rounded-full bg-green-600"></span>
                                                Active
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-1 text-xs noto-sans-regular text-red-600">
                                                <span className="h-1.5 w-1.5 rounded-full bg-red-600"></span>
                                                Inactive
                                            </span>
                                        )}
                                    </td>
                                    <td className="px-2 h-12">
                                        <div className="flex justify-end gap-4">
                                            <button
                                                onClick={() => goToPage(device.HOEProductID, device.status)}
                                                className="noto-sans-regular bg-[#075289] hover:bg-[#9BB9CF] transition duration-100 ease-in-out text-white text-xs h-8 py-1 px-5 rounded"
                                            >
                                                View
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
            )
            }
        </div>
    )
}

export default Table;