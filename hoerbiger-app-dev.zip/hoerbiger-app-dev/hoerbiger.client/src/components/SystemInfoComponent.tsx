import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { SystemInfo } from "../model/SystemInfo";
import HeaderBar from "./HeaderBar";
import { ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import { useDispatch } from "react-redux";
import { setPageName } from '../features/pageName/pageNameSlice';


function SystemInfoComponent() {

    const [systemInfoData, setSystemInfoData] = useState<SystemInfo>();
    const { deviceId } = useParams<{ deviceId: string }>();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const goToPage = (pageName: string) => {
        dispatch(setPageName({ pageName: pageName }));
        if (pageName == "listOfSystems") {
            navigate("/");
        }
        else //navigate(`/${deviceId}/${pageName}`);
            navigate(`/${deviceId}`);
    }

    const fetchSystemInfoData = async (key: string) => {
        const response = await fetch(`api/systeminfo/${key}`);
        if (response.ok) {
            const data = await response.json();
            setSystemInfoData(data);
        }
    };

    useEffect(() => {
        if (deviceId) fetchSystemInfoData(deviceId);
    }, []);


    return (
        <div className="w-full  ">
            <div className="border border-gray-200 p-[32px] w-full h-[453px mx-auto bg-white shadow-md">
                <div className="flex justify-between">
                    <HeaderBar headerText={`System info - ${deviceId}`} />
                    <ArrowTopRightOnSquareIcon className="w-5 mt-[-20px]" onClick={() => goToPage("systemInfo")} />
                </div>

                {/* Tables Container */}
                {systemInfoData && (
                    <div className="flex flex-col justify-center ">
                        {["tsSystem", "tsBoardCU", "tsBoardHMI"].map((key, index) => (
                            <table
                                key={key}
                                className={`w-full h-auto `}
                            >
                                <thead>
                                    <tr className="border-b">
                                        <th className="pl-2 pb-3 pt-[40px] text-gray-900 text-left">
                                            {key === "tsSystem"
                                                ? "TS System"
                                                : key === "tsBoardCU"
                                                    ? "TS Board CU"
                                                    : "TS Board HMI"}
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {[
                                        "baseVersion",
                                        "subVersion",
                                        "busCommVersion",
                                        "secretVersion",
                                        "standaloneVersion",
                                        "productionWeek",
                                        "productionYear",
                                        "manufacturerName",
                                    ].map(
                                        (param) =>
                                            systemInfoData[key][param] && (
                                                <tr
                                                    key={param}
                                                    className="border-b text-[#464646] "
                                                >
                                                    <td className="capitalize pl-2 py-3 noto-sans-medium">
                                                        {param === "manufacturerName"
                                                            ? "Manufacturer Name"
                                                            : param.replace(/([A-Z])/g, " $1").trim()}
                                                    </td>

                                                    <td
                                                        className="text-right truncate pr-2 noto-sans-regular"
                                                        style={{
                                                            maxWidth: "200px",
                                                            textOverflow: "ellipsis",
                                                            overflow: "hidden",
                                                            whiteSpace: "nowrap",
                                                        }}
                                                    >
                                                        {systemInfoData[key][param]}
                                                    </td>
                                                </tr>
                                            )
                                    )}
                                </tbody>
                            </table>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export default SystemInfoComponent;