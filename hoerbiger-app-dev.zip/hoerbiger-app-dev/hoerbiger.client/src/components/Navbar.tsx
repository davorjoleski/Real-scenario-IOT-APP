﻿import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from 'react-router-dom';
import { setPageName } from '../features/pageName/pageNameSlice';
import logo_small from "../assets/Logos/hoerbiger-logo-small.jpg"
import logo_big from "../assets/Logos/hoerbiger-logo.png"
import "../sideBar.css"
import { RootState } from '../main'
import { InboxIcon, DocumentChartBarIcon, ClipboardIcon, PresentationChartLineIcon, RectangleGroupIcon, AdjustmentsVerticalIcon, ArrowRightEndOnRectangleIcon, BellAlertIcon, Cog8ToothIcon, ComputerDesktopIcon, ChevronLeftIcon, ChevronRightIcon } from '@heroicons/react/24/outline';

function Navbar({ pageName, status }: { pageName: string, status: boolean }) {
    //const [showPages, setShowPages] = useState(false);
    const [isSidebarCollapsed, setSidebarCollapsed] = useState(false); // Added sidebar collapse


    const { deviceId } = useParams<{ deviceId: string }>();
    const currentPage = useSelector((state: RootState) => state.pageName.pageName);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const goToPage = (pageName: string) => {
        dispatch(setPageName({ pageName: pageName }));
        if (pageName == "listOfSystems") {
            navigate("/");
        }
        else //navigate(`/${deviceId}/${pageName}`);
            navigate(`/${deviceId}`);
    }

    const icons = {
        listOfSystems: ComputerDesktopIcon,
        systemInfo: DocumentChartBarIcon,
        dashBoard: RectangleGroupIcon, // Ова е Dashboard иконата

        realtimeInfo: PresentationChartLineIcon,
        dataArchive: InboxIcon,
        parameters: AdjustmentsVerticalIcon,
        capture: Cog8ToothIcon,
        diagnostic: ClipboardIcon,
        alerts: BellAlertIcon,
    } as const;
    type PageName = keyof typeof icons;


 


    return (

        <div className="flex h-screen">
            {/* Sidebar */}
            <nav className={`sidebar ${isSidebarCollapsed ? "collapsed" : "expanded"}`}>
                {/* Toggle Button */}
                <div className="sidebar-toggle-container">
                    <button
                        className="sidebar-toggle-button"
                        onClick={() => setSidebarCollapsed((prev) => !prev)}
                    >
                        {isSidebarCollapsed ? (
                            <ChevronRightIcon className="sidebar-toggle-icon" />
                        ) : (
                            <ChevronLeftIcon className="sidebar-toggle-icon" />
                        )}
                    </button>
                </div>

                {/* Logo */}
                <div
                    className="sidebar-logo"
                    style={{
                        width: isSidebarCollapsed ? "52px" : "182px",
                        height: isSidebarCollapsed ? "34px" : "63px",
                        top: isSidebarCollapsed ? "98px" : "66px",
                        left: isSidebarCollapsed ? "14px" : "38px",
                    }}
                >
                    <img src={isSidebarCollapsed ? logo_small : logo_big} alt="Hoerbiger" />
                </div>

                {/* Navigation */}
                <div className="sidebar-nav">
                    {([
                        { name: "listOfSystems", label: "List of systems" },
                        { name: "systemInfo", label: "System info" },
                        { name: "dashBoard", label: "Dashboard"},

                        { name: "realtimeInfo", label: "Real-time info" },
                        { name: "dataArchive", label: "Data archive" },
                        { name: "parameters", label: "Parameters" },
                        { name: "capture", label: "Capture" },
                        { name: "diagnostic", label: "Diagnostic" },
                        { name: "alerts", label: "Alerts" },
                    ] as { name: string; label: string }[]).map(({ name, label }) => {
                        //const isDisabled = !status && !["dataArchive", "alerts", "listOfSystems"].includes(name);
                        const isDisabled = name === "capture" || name === "diagnostic" || 
                            (!status && !["dataArchive", "alerts", "listOfSystems"].includes(name)) ||
                            (currentPage === "listOfSystems" && ["dataArchive", "alerts"].includes(name));
                        const Icon = icons[name];

                        return (
                            <button
                                key={name}
                                onClick={() => !isDisabled && goToPage(name)}
                                className={`sidebar-button ${currentPage === name ? "active" : "inactive"} ${!isDisabled ? "" : "disabled"}`}
                                disabled={isDisabled}
                            >
                                <div className={`sidebar-icon-container ${isSidebarCollapsed ? "ml-4" : "ml-[40px]"}`}>
                                    {Icon && <Icon className={`sidebar-icon ${currentPage === name ? "active" : "inactive"}`} />}
                                    <span className={`${isSidebarCollapsed ? "opacity-0" : "opacity-100"} transition-opacity duration-500`}>
                                        {!isSidebarCollapsed && label}
                                    </span>
                                </div>

                                {/* Highlight current page */}
                                {currentPage === name && <span className="sidebar-highlight"></span>}
                            </button>
                        );
                    })}
                </div>




                {/* Logout Button */}
                <button
                    className="sidebar-logout flex items-center w-full px-4 py-2 mt-4"
                    onClick={() => {
                        const logoutUrl = "https://hoerbiger-client-dev-czawc3d5cjeecqas.westeurope-01.azurewebsites.net/.auth/logout";
                        const postLogoutRedirectUri = "https://hoerbiger-client-dev-czawc3d5cjeecqas.westeurope-01.azurewebsites.net/";

                        window.location.href =  `${logoutUrl}?post_logout_redirect_uri=${encodeURIComponent(postLogoutRedirectUri)}`;
                    }}
                >
                    <div className={`sidebar-icon-container ${isSidebarCollapsed ? "ml-4" : "ml-[40px]"} flex items-center`}>
                        <ArrowRightEndOnRectangleIcon className="sidebar-logout-icon mr-2" />
                        <span className={`${isSidebarCollapsed ? "opacity-0" : "opacity-100"} transition-opacity duration-500`}>
                            {!isSidebarCollapsed && "Logout"}
                        </span>
                    </div>
                </button>





            </nav>
        </div>
  

    );




}






export default Navbar;