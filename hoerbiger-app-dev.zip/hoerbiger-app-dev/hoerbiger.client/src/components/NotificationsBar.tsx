import { XMarkIcon } from "@heroicons/react/24/solid";
import HeaderBar from "./HeaderBar";
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setPageName } from '../features/pageName/pageNameSlice';
import NotificationsBarItem from "./NotificationsBarItem";
import { useEffect, useState } from "react";
import { getTimeAgo } from "../services/TimeAgoNotification";
import { AlertProps } from "../views/AlertsView";
import { Alert } from "../model/Alert";

interface NotificationsBarProps {
    isOpen: boolean;
    onClose: () => void;
}

const NotificationsBar: React.FC<NotificationsBarProps> = ({ isOpen, onClose }) => {

    const { deviceId } = useParams<{ deviceId: string }>();
    const [notificationsData, setNotificationsData] = useState<AlertProps[]>();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const todayDate = new Date().toISOString().split("T")[0];
    let todayNotifications;
    let olderNotifications;

    const goToPage = (pageName: string) => {
        dispatch(setPageName({ pageName: pageName }));
        navigate(`/${deviceId}`);
    }


    const fetchAlarms = async (key: string) => {
        const response = await fetch(`api/alerts/${key}`);
        if (response.ok) {
            const data = await response.json();
            console.log("cosmos: ", data)
            const formattedData = data.map((alert: Alert) => ({
                id: alert.id,
                alertId: alert.alertId,
                diagnosticId: alert.diagnostic_ID,
                iotSerial: alert.serial_number_IOT,
                systemSerial: alert.serial_number_system,
                time: alert.timestamp,
                isRead: alert.isRead,
                timeAgo: getTimeAgo(alert.timestamp),
            }));
            setNotificationsData(formattedData);
        }
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toISOString().split("T")[0];
    };

    if (notificationsData != undefined) {
        todayNotifications = notificationsData.filter(
            (item) => formatDate(item.time) === todayDate
        );
        olderNotifications = notificationsData.filter(
            (item) => formatDate(item.time) !== todayDate
        );
    }
    console.log("today ", todayNotifications)
    console.log("older ", olderNotifications)

    useEffect(() => {
        if (deviceId) {
            fetchAlarms(deviceId);
        }
    }, [isOpen, deviceId]);


    return (
        <div className={`flex flex-col fixed top-0 right-0 w-[424px] p-[24px] h-full bg-white shadow-lg transform transition-transform duration-300 ${isOpen ? "translate-x-0" : "translate-x-full"}`}>
            {/* Header */}
            <div className="flex justify-between items-center mb-5 ">
                <HeaderBar headerText={`System ${deviceId} notifications`} />
                <button onClick={onClose}>
                    <XMarkIcon className="w-5 h-5 cursor-pointer" />
                </button>
            </div>

            {/* Notification Content */}
            <div className=" noto-sans-regular flex-grow overflow-auto">
                <div className="text-[10px] text-[#8D8D8D] p-1 border-b">TODAY</div>

                {todayNotifications != undefined && todayNotifications.length > 0 ? (
                    todayNotifications.map((item, index) => <NotificationsBarItem key={index} {...item} />)
                ) : (
                    <div className="text-center text-gray-500 text-sm">No new notifications</div>
                )}

                <div className="text-[10px] text-[#8D8D8D] mt-5 p-1 border-b">OLDER</div>

                {olderNotifications != undefined && olderNotifications.length > 0 ? (
                    olderNotifications.map((item, index) => <NotificationsBarItem key={index} {...item} />)
                ) : (
                    <div className="text-center text-gray-500 text-sm">No older notifications</div>
                )}

            </div>

            <div className="flex justify-center pt-3">
                <button
                    onClick={() => goToPage("alerts")}
                    className=" noto-sans-regular bg-[#075289] hover:bg-[#9BB9CF] transition duration-100 ease-in-out text-white text-xs h-8 py-1 px-5 rounded"
                >
                    View All
                </button>
            </div>
        </div>
    );
};

export default NotificationsBar;
