import { MinusIcon } from "@heroicons/react/24/outline";
import { PlusIcon } from "@heroicons/react/24/solid";
import { useState, useEffect } from "react";

interface CustomNumberInputProps {
    value: number;
    initValue: number;
    onChange: (newValue: number) => void;
}
function CustomNumberInput({ value, initValue, onChange }: CustomNumberInputProps) {
    const [amount, setAmount] = useState(value);
    const [modified, setModified] = useState(initValue!=value);

    useEffect(() => {
        setAmount(value);
        setModified(value!=initValue)
    }, [value]);

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.value;

        if (newValue === "") {
            setAmount(0);
            return;
        }

        const parsedValue = parseInt(newValue, 10);
        if (!isNaN(parsedValue)) {
            onChange(parsedValue);
            setAmount(parsedValue);
        }
        setModified(initValue!=parsedValue);

    };

    const decrement = () => {
        setAmount((prev) => {
            const newValue = Math.max(0, prev - 1);
            onChange(newValue);
            setModified(initValue!=newValue);
            return newValue;
        });
    };

    const increment = () => {
        setAmount((prev) => {
            const newValue = prev + 1;
            onChange(newValue);
            setModified(initValue!=newValue);
            return newValue;
        });
        
    };

    return (
        <div className="flex max-w-xs">
            <div className={`relative flex items-center w-[5rem]  rounded-lg ${modified ? "ring-1 ring-red-500" : ""}`}>
                <button type="button"
                    id="decrement-button"
                    onClick={decrement}
                    className="gray-bg dark:bg-gray-700 dark:hover:bg-gray-600 dark:border-gray-600 hover:bg-gray-300 border border-custom-gray rounded-s-lg p-1 focus:ring-gray-100 dark:focus:ring-gray-700 focus:ring-2 focus:outline-none">
                    <MinusIcon className="w-4 h-4 text-gray-900 dark:text-white" />
                </button>
                <input type="text"
                    id="bedrooms-input"
                    className=" border-x-0 border-gray-300 w-full h-[25px] font-medium text-center text-gray-900 border border-custom-gray text-sm flex items-center justify-center focus:ring-blue-500 focus:border-blue-500 block dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder=""
                    value={amount}
                    onChange={handleChange}
                    required />

                <button type="button"
                    id="increment-button"
                    onClick={increment}                  
                    className="gray-bg dark:bg-gray-700 dark:hover:bg-gray-600 dark:border-gray-600 hover:bg-gray-300 border border-custom-gray rounded-e-lg p-1 focus:ring-gray-100 dark:focus:ring-gray-700 focus:ring-2 focus:outline-none">
                    <PlusIcon className="w-4 h-4 text-gray-900 dark:text-white" />
                </button>
            </div>
        </div>
    );
}
export default CustomNumberInput;