import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { Provider } from 'react-redux'
import { configureStore, combineReducers } from "@reduxjs/toolkit";
import pageNameReducer from "./features/pageName/pageNameSlice.ts";
import systemsStausReducer from "./features/systemsStatus/SystemsStatusSlice.ts";

const rootReducer = combineReducers({
    pageName: pageNameReducer,
    systemsStatus: systemsStausReducer,
});


const store = configureStore({
    reducer: {
        pageName: pageNameReducer,
        systemsStatus: systemsStausReducer,
    },
});

export type RootState = ReturnType<typeof rootReducer>;

createRoot(document.getElementById('root')!).render(
    <Provider store={store}>
        <App />
    </Provider>,
)
