﻿import "../App.css";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { SystemInfo } from "../model/SystemInfo.ts";
import HeaderBar from "../components/HeaderBar.tsx";

function SystemInfoView() {
    const [systemInfoData, setSystemInfoData] = useState<SystemInfo>();
    const { deviceId } = useParams<{ deviceId: string }>();

    const fetchSystemInfoData = async (key: string) => {
        const response = await fetch(`api/systeminfo/${key}`);
        if (response.ok) {
            const data = await response.json();
            setSystemInfoData(data);
        }
    };

    useEffect(() => {
        if (deviceId) fetchSystemInfoData(deviceId);
    }, []);

    return (
        <div className="px-[60px]">
            <div className="border border-gray-200 p-[32px] font-[Noto Sans] w-full h-[453px] mx-auto bg-white shadow-md">
                {/* Header */}
                <HeaderBar headerText={`System info - ${deviceId}`} />


                {/* Tables Container */}
                {systemInfoData && (
                    <div className="flex justify-center items-center pt-7">
                        {["tsSystem", "tsBoardCU", "tsBoardHMI"].map((key, index) => (
                            <table
                                key={key}
                                className={`w-1/3 h-auto ${index === 0 ? "ml-[30px]" : index === 2 ? "mr-[30px]" : "mx-[35px]"
                                    }`}
                            >
                                <thead>
                                    <tr className="border-b">
                                        <th className="pb-2 px-2 text-gray-900 text-left">
                                            {key === "tsSystem"
                                                ? "TS System"
                                                : key === "tsBoardCU"
                                                    ? "TS Board CU"
                                                    : "TS Board HMI"}
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {[
                                        "baseVersion",
                                        "subVersion",
                                        "busCommVersion",
                                        "secretVersion",
                                        "standaloneVersion",
                                        "productionWeek",
                                        "productionYear",
                                        "manufacturerName",
                                    ].map(
                                        (param) =>
                                            systemInfoData[key][param] && (
                                                <tr
                                                    key={param}
                                                    className="border-b"
                                                    style={{ width: "330.29px", height: "52px" }}
                                                >
                                                    <td className="pr-2 pl-2 py-1 text-gray-700 capitalize font-[Noto Sans]">
                                                        {param === "manufacturerName"
                                                            ? "Manufacturer Name"
                                                            : param.replace(/([A-Z])/g, " $1").trim()}
                                                    </td>

                                                    <td
                                                        className="text-center text-gray-900 font-[Noto Sans] truncate"
                                                        style={{
                                                            maxWidth: "200px",
                                                            textOverflow: "ellipsis",
                                                            overflow: "hidden",
                                                            whiteSpace: "nowrap",
                                                        }}
                                                    >
                                                        {systemInfoData[key][param]}
                                                    </td>
                                                </tr>
                                            )
                                    )}
                                </tbody>
                            </table>
                        ))}
                    </div>
                )}
            </div>
        </div>



    );
}

export default SystemInfoView;
