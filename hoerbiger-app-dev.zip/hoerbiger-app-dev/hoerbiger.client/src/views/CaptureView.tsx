import HeaderBar from "../components/HeaderBar";

function CaptureView() {

    return (
        <div className="nav">
            <HeaderBar headerText={`Capture`} />
            capture
        </div>
    )
}

export default CaptureView;