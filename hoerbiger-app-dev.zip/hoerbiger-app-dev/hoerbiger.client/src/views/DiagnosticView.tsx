import HeaderBar from "../components/HeaderBar";

function DiagnosticView() {

    return (
        <div className="nav">
            <HeaderBar headerText={`Diagnostic`} />
            diagnostic
        </div>
    )
}

export default DiagnosticView; 