import CustomLineChart from "../components/CustomLineChart";

function DataArchiveView() {

    return (
        <div className=" px-[60px]">
            <CustomLineChart />
        </div>
    )
}

export default DataArchiveView;