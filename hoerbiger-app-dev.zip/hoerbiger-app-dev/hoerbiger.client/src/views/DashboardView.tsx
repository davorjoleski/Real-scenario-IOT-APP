import DataArchiveComponent from "../components/DataArchiveComponent";
import ParametersComponent from "../components/ParametersComponent";
import RealtimeDataComponent from "../components/RealtimeDataComponent";
import SystemInfoComponent from "../components/SystemInfoComponent";

function DashboardView() {


    return (
        <div className="w-full px-[60px] pb-[60px]">
            <RealtimeDataComponent  />
            <div className="flex pt-[32px]">
                <div className="w-1/2  pr-[16px] flex flex-col">
                    <DataArchiveComponent />
                    <div className="pt-[32px]">
                        <ParametersComponent  />
                    </div>
                </div>
                <div className="w-1/2 pl-[16px]">
                    <SystemInfoComponent  />
                </div>
            </div>
        </div>
    );
}

export default DashboardView;