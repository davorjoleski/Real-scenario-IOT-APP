import { useNavigate, useParams } from "react-router-dom";
import SystemInfoView from "./SystemInfoView";
import RealtimeInfoView from "./RealtimeInfoView";
import DataArchiveView from "./DataArchiveView";
import ParametersView from "./ParametersView";
import CaptureView from "./CaptureView";
import DiagnosticView from "./DiagnosticView";
import AlertsView from "./AlertsView";
import Navbar from "../components/Navbar";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from '../main'
import { setPageName } from "../features/pageName/pageNameSlice";
import { setSystemsStatus } from "../features/systemsStatus/SystemsStatusSlice.ts";
import { Slide, toast, ToastContainer } from "react-toastify";
import { BellIcon } from "@heroicons/react/24/solid";
import NotificationsBar from "../components/NotificationsBar.tsx";
import DashboardView from "./DashboardView.tsx";

function DeviceView() {
    const { deviceId } = useParams<{ deviceId: string }>();
    const pageName = useSelector((state: RootState) => state.pageName.pageName);
    const allStatuses = useSelector((state: RootState) => state.systemsStatus.statuses);
    const previousStatus = allStatuses.filter(device => device.HOEProductID == deviceId).at(0)?.status;
    const [systemStatus, setSystemStatus] = useState<boolean>(previousStatus);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
    const [hasNewNotification, setHasNewNotification] = useState<boolean>(false);

    const toggleNotificationsbar = () => {
        setIsNotificationsOpen(!isNotificationsOpen);
        if (!isNotificationsOpen) {
            markAllAlertsAsRead();
            setHasNewNotification(false);
        }
    };

    const markAllAlertsAsRead = async () => {
        const response = await fetch(`api/alerts/${deviceId}/read`, {
            method: "post",
        });

        if (response.ok) {
            setHasNewNotification(false);
        }
    };

    const fetchSystemStatus = async () => {
        const response = await fetch(`api/listofsystems/${deviceId}`);
        if (response.ok) {
            const data: boolean = await response.json();
            if (data)
                setSystemStatus(true);
            else setSystemStatus(false);
        }
    }

    const fetchSystemNewAlerts = async () => {
        const response = await fetch(`api/alerts/${deviceId}/latestIsRead`);
        if (response.ok) {
            const data: any = await response.json();
            if (!data.isRead) 
                setHasNewNotification(true);
            console.log("here")
        }
    }

    const getPageComponent = () => {
        switch (pageName) {
            case 'systemInfo':
                return <SystemInfoView />;
            case 'dashBoard':
                return <DashboardView />;
            case 'realtimeInfo':
                return <RealtimeInfoView />;
            case 'dataArchive':
                return <DataArchiveView />;
            case 'parameters':
                return <ParametersView />;
            case 'capture':
                return <CaptureView />;
            case 'diagnostic':
                return <DiagnosticView />;
            case 'alerts':
                return <AlertsView />;
            default:
                return <SystemInfoView />;
        }
    };

    useEffect(() => {
        fetchSystemNewAlerts();
    });

    useEffect(() => {
        setIsNotificationsOpen(false);
    }, [pageName]);

    useEffect(() => {
        if (previousStatus == false) {
            return;
        }
        const intervalId = setInterval(() => {
            fetchSystemStatus();
        }, 5000);

        const eventSource = new EventSource(`api/alerts/subscribe/${deviceId}`);

        eventSource.onmessage = (event) => {
            console.log('Received message', event.data);
            setHasNewNotification(true);

            toast.success(event.data, {
                position: "top-center",
                autoClose: 10000,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
                transition: Slide,
            });
        };

        eventSource.onerror = () => {
            console.error("SSE connection error");
            eventSource.close();
        };

        return () => {
            eventSource.close();
            clearInterval(intervalId);
        };
    }, [deviceId]);

    useEffect(() => {
        if (systemStatus === false && previousStatus != false) {
            //alert("Device is inactive");
            toast.error('Device is inactive.', {
                position: "top-center",
                autoClose: 10000,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
                transition: Slide,
            });

            setTimeout(() => {
                const updatedStatuses = allStatuses.map(device =>
                    device.HOEProductID === deviceId ? { ...device, status: false } : device
                );

                dispatch(setPageName({ pageName: "listOfSystems" }));
                dispatch(setSystemsStatus({ statuses: updatedStatuses }))

                navigate("/");
            }, 10500);
        }
    }, [systemStatus, navigate]);


    const PageComponent = getPageComponent();

    return (
        <div className="flex h-screen bg-[#FAFAFA]">
            <Navbar pageName={pageName || "Default Page"} status={previousStatus || systemStatus} />

            {isNotificationsOpen && (
                <div
                    className="fixed inset-0 bg-black bg-opacity-50 transition-opacity duration-300 z-10"
                    onClick={toggleNotificationsbar}
                ></div>
            )}

            <div className={`flex-1 overflow-auto p-0 transition-all duration-300 ${isNotificationsOpen ? "z-0" : "z-20"}`}>
                <div className="h-[60px] pt-[20px] pr-[20px] flex justify-end">
                    {pageName !== "alerts" && (
                        <div className="relative z-20" onClick={toggleNotificationsbar}>
                            <div className="pt-1">
                                <BellIcon className="w-[24px] h-[24px]" />
                            </div>
                            {hasNewNotification && (
                                <span className="absolute top-0 right-0 flex size-3">
                                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#8D172E] opacity-75"></span>
                                    <span className="relative inline-flex size-3 rounded-full bg-[#8D172E]"></span>
                                </span>
                            )}
                        </div>
                    )}
                </div>

                {PageComponent}

            </div>

            <div className="relative z-20">
                <NotificationsBar isOpen={isNotificationsOpen} onClose={toggleNotificationsbar} />
            </div>

            <ToastContainer />
        </div>
    );
}
export default DeviceView;

