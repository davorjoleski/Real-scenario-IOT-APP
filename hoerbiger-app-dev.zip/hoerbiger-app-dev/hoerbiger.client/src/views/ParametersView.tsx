import React, { useState, useEffect, CSSProperties } from "react";
import { useParams } from "react-router-dom";
import { Slide, toast } from "react-toastify";

import { Parameters } from "../model/Parameters.ts";
import CustomNumberInput from "../components/CustomNumberInput.tsx";
import HeaderBar from "../components/HeaderBar.tsx";
import ClipLoader from "react-spinners/ClipLoader";

const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
};

const ParametersView: React.FC = () => {
    const [parameters, setParameters] = useState<Parameters | null>(null);
    const [initParameters, setInitParameters] = useState<Parameters | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const { deviceId } = useParams<{ deviceId: string }>();

    const notify = () => toast.success('Parameters updated successfully!', {
        position: "bottom-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Slide,
    });

    const notifyError = () => toast.error(error, {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: false,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        transition: Slide,
    });



    // Fetch the device parameters
    useEffect(() => {
        const fetchParameters = async () => {
            try {
                setLoading(true);
                setError(null);
                const response = await fetch(`/api/params/${deviceId}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch: ${JSON.parse(await response.text()).message}`);
                }
                const data: Parameters = await response.json();
                setParameters(data);
                setInitParameters(data);
            } catch (err) {
                setError((err as Error).message);
            } finally {
                setLoading(false);
            }
        };

        fetchParameters();
    }, []);

    const isParameterChanged = JSON.stringify(initParameters) !== JSON.stringify(parameters);

    const handleUpdate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!parameters) return;

        try {
            setLoading(true);
            setError(null);

            const response = await fetch(`/api/params/${deviceId}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(parameters),
            });

            if (!response.ok) {
                throw new Error(`Failed to update: ${JSON.parse(await response.text()).message}`);
            }

            const updatedData: Parameters = await response.json();
            setParameters(updatedData);
            setInitParameters(updatedData);
            notify()
        } catch (err) {
            setError((err as Error).message);
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setParameters((prev) => {
            if (!prev) return null;
            return {
                ...prev,
                [name]: isNaN(Number(value)) ? value : Number(value),
            };
        });
    };

    const handleReset = () => {
        setParameters(initParameters);
    }

    if (loading) return <ClipLoader cssOverride={override} />;
    if (error) {
        notifyError();
        setError(null)
    }



    return (
        <div className="flex-1 px-[60px] overflow-auto ml-[0px]">

            {parameters ? (
                <div className="flex justify-start">

                    <form onSubmit={handleUpdate} className="bg-white border border-black-200 p-[32px] w-[430px] min-h-[50vh] shadow-md">
                        <div className="mb-5">
                            <HeaderBar headerText={`Device parameters - ${deviceId}`} />
                        </div>

                        {Object.entries(parameters).map(([key, value]) => (
                            <div key={key} className="flex justify-between py-2 border-b border-black-300">

                                <div className="flex justify-content items-center text-black text-sm pl-2" >
                                    {key.replace(/_/g, " ")}:

                                </div>

                                <CustomNumberInput value={value} initValue={initParameters[key]} onChange={(newValue) => handleChange({ target: { name: key, value: newValue.toString() } } as React.ChangeEvent<HTMLInputElement>)} />
                            </div>
                        ))}
                        <div className="flex justify-center mt-11 space-x-4 p-4">
                            <button type="button" disabled={!isParameterChanged}
                                className="bg-[#8D8D92] disabled:bg-[#E5E5E5] hover:bg-[#E5E5E5] text-white px-4 py-2 w-[88px] rounded-md"
                                onClick={handleReset} >Reset</button>

                            <button type="submit" disabled={!isParameterChanged} className="bg-[#075289] hover:bg-[#9BB9CF] text-white px-4 py-2 w-[88px] rounded-md">
                                Update
                            </button>
                        </div>
                    </form>
                </div>
            ) : (
                <p>No parameters loaded.</p>
            )}
        </div>
    );
};

export default ParametersView;