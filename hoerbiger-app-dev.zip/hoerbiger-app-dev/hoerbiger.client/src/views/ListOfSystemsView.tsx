import Table from "../components/Table.tsx";
import '../App.css'
import Navbar from "../components/Navbar.tsx";
import { useEffect, useState } from "react";
import { Device } from "../model/Device.ts"
import { StatusCacheEntry } from "../model/SystemStatus.ts";
import { useDispatch } from "react-redux";
import { setSystemsStatus } from "../features/systemsStatus/SystemsStatusSlice.ts";

function ListOfSystemsView() {
    const [systems, setSystems] = useState<Device[]>([]);
    const dispatch = useDispatch();

    const fetchSystemIds = async () => {
        const response = await fetch(`api/listofsystems`);
        //console.log("here", response.json)
        if (response.ok) {
            const data: StatusCacheEntry[] = await response.json();

            const devices: Device[] = data.map((item) => ({
                HOEProductID: item.key,
                status: item.value.status,
            }));
            setSystems(devices);
            dispatch(setSystemsStatus({ statuses: devices }));

        }
    }

    useEffect(() => {
       
        const intervalId = setInterval(() => {
            fetchSystemIds();
        }, 5000);

        return () => clearInterval(intervalId);
    }, []); 

    useEffect(() => {
        fetchSystemIds();
    }, []);


    return (

        <div className="flex min-h-screen" style={{ backgroundColor: '#fafafa' }}>
            {/* Sidebar (left menu) */}
            <Navbar pageName="listOfSystems" />

            {/* Main content */}
            <div className="flex-1 p-0 overflow-auto ml-[0px]">


                <Table values={systems} />
            </div>
        </div>

    );
}

export default ListOfSystemsView;