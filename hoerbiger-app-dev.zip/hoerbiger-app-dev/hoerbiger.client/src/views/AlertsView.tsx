﻿import React, { useState, useEffect, CSSProperties } from "react";
import { useParams } from "react-router-dom"; 
import { Switch } from "@headlessui/react";
import { getTimeAgo } from "../services/TimeAgoNotification";
import HeaderBar from "../components/HeaderBar";
import { ClipLoader } from "react-spinners";
import { Alert } from "../model/Alert";

export interface AlertProps {
    id: string;
    alertId: string;
    systemSerial: string;
    iotSerial: string;
    diagnosticId: string;
    time: string;
    isRead: boolean;
    timeAgo: string;
}

const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
};

const AlertList: React.FC = () => {
    const { deviceId } = useParams<{ deviceId: string }>(); 
    const [enabled, setEnabled] = useState(true);
    const [alerts, setAlerts] = useState<AlertProps[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [continuationToken, setContinuationToken] = useState<string | null>(null);
    const [hasMore, setHasMore] = useState<boolean>(true);

    const fetchPaginatedAlerts = async (pageSize = 9, token: string | null = null) => {
        setIsLoading(true);
        if (token !== null) {
            console.log("Continuation token:", encodeURIComponent(token));
        }
        console.log("DeviceId: ", deviceId);
        try {
            const tokenParam = token ? `&continuationToken=${encodeURIComponent(token)}` : "";
            const url = `/api/alerts/${deviceId}/paginated?pageSize=${pageSize}${tokenParam ? `&token=${encodeURIComponent(token)}` : ""}`;
            console.log("URL: ", url);
            const response = await fetch(`/api/alerts/${deviceId}/paginated?pageSize=${pageSize}${tokenParam}`);
            if (!response.ok) throw new Error("Failed to fetch alerts");

            const data = await response.json();
            const formattedAlerts = data.alerts.map((alert: Alert) => ({
                        id: alert.id,
                        alertId: alert.alertId,
                        diagnosticId: alert.diagnostic_ID,
                        iotSerial: alert.serial_number_IOT,
                        systemSerial: alert.serial_number_system,
                        time: alert.timestamp,
                        timeAgo: getTimeAgo(alert.timestamp),
            }));
            console.log("Formatted Data: ", formattedAlerts)
            setAlerts((prevAlerts) => [...prevAlerts, ...formattedAlerts]);
            setEnabled(data.deviceStatus.canSend);
            setContinuationToken(data.continuationToken);
            setHasMore(!!data.continuationToken);
        } catch (err) {
            setError("Failed to load alerts");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleSwitchChange = async () => {
        if (!deviceId) return;
        try {
            const response = await fetch(`/api/alerts/${deviceId}/toggleAlarmStatus`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
            });
            if (response.ok) {
                setEnabled((prevStatus) => !prevStatus);
            } else {
                setError("Failed to toggle alarm status");
            }
        } catch (err) {
            setError("Error toggling alarm status");
            console.error(err);
        }
    };

    useEffect(() => {

        if (!deviceId) return;
        setContinuationToken(null);
        setAlerts([]);
        fetchPaginatedAlerts(9, null);

    }, [deviceId]);

    const loadMoreAlerts = () => {
        if (!!deviceId && hasMore && continuationToken) {
            fetchPaginatedAlerts(9, continuationToken);
        }
    };

    if (isLoading) return <ClipLoader cssOverride={override}/>;
    if (error) return <p className="text-center text-red-500">{error}</p>;

    return (
        <div className="px-[60px] pb-[60px]">

            <div className="bg-white border border-black-200 p-[32px] flex-grow w-full shadow-md">

                <div className="flex items-center justify-between w-full pb-7">
                    <HeaderBar headerText={`Alerts for - ${deviceId}`} />

                    <Switch
                        checked={enabled}
                        onChange={handleSwitchChange}
                        className={`${enabled ? "bg-[#178D76]" : "bg-[#8D172E]"}  relative inline-flex items-center h-6 rounded-full w-11 transition`}
                    >
                        <span className="sr-only">Enable alerts</span>
                        <span className={`${enabled ? "translate-x-6" : "translate-x-1"} inline-block w-4 h-4 transform bg-white rounded-full transition`} />
                    </Switch>

                </div>

                {alerts.length === 0 ? (
                    <div>
                        <p className="noto-sans-bold py-6 px-2 h-16 text-sm">No alarms found</p>
                    </div>
                ): (
                        <div>
                            <div className="flex justify-between grid grid-cols-3 gap-11 max-h-[560px] overflow-auto">

                                {alerts?.map((alert: AlertProps) => (


                                    <div key={alert.alertId} className="w-full bg-white border border-[#D4D4D4] noto-sans-medium flex flex-col justify-betwee pl-4 pt-4 pb-2 pr-2">
                                        <h2 className="text-sm noto-sans-bold pb-2">Alert - {alert.alertId}</h2>
                                        <div className="flex">
                                            <div className="border-l-2 border-[#464646] p-1 h-auto pl-2 text-xs text-[#8D8D92]">
                                                <p>Serial number system: "{alert.systemSerial}"</p>
                                                <p>Serial number IOT: "{alert.iotSerial}"</p>
                                                <p>Diagnostic ID: "{alert.diagnosticId}"</p>
                                            </div>
                                        </div>
                                        <p className="text-[10px] text-[#8D8D92] text-right">{alert.timeAgo}</p>
                                    </div>
                                ))}
                            </div>
                            {
                                hasMore &&
                                <div className="mt-7 flex justify-center">
                                    <button
                                        className="text-center noto-sans-semibold bg-[#075289] hover:bg-[#9BB9CF] transition duration-100 ease-in-out text-white text-xs h-8 py-1 px-5 rounded"
                                        onClick={loadMoreAlerts}>
                                        Load more
                                    </button>
                                </div>
                            }
                        </div>
                )}

            </div>
        </div>
    );

};

export default AlertList;
