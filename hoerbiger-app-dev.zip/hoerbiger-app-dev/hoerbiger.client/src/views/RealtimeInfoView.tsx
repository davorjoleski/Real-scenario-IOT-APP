import { useParams } from "react-router-dom";
import { CSSProperties, useEffect, useState } from "react";
import { RealTimePeriodicData } from "../model/RealTimeData";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";
import HeaderBar from "../components/HeaderBar";
import ClipLoader from "react-spinners/ClipLoader";

const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
};

function RealtimeInfoView() {
    const { deviceId } = useParams<{ deviceId: string }>();
    const [data, setData] = useState<RealTimePeriodicData | null>(null);


    //Browser temporary storage for real time data
    const [dataCache, setDataCache] = useState<any[] | null>([]);

    //Set tab view, for different threshold values we have different tabs
    const [activeTab, setActiveTab] = useState(1);

    //To know whether or not to show line in LineChart for a specific parameter
    const [showInputPressureO2, setShowInputPressureO2] = useState(true);
    const [showInputPressureN2, setShowInputPressureN2] = useState(true);
    const [showOutputPressureO2, setShowOutputPressureO2] = useState(true);
    const [showOutputPressureN2, setShowOutputPressureN2] = useState(true);
    const [showFlowO2, setShowFlowO2] = useState(false);
    const [showFlowN2, setShowFlowN2] = useState(false);
    const [showSetpointO2, setShowSetpointO2] = useState(true);
    const [showCurrentValueO2, setShowCurrentValueO2] = useState(true);
    const [showState, setShowState] = useState(true);

    const [fields, setFields] = useState<string[]>(['InputO2_P1_bar', 'InputN2_P1_bar', 'OutputO2_P2_bar', 'OutputN2_P2_bar', 'FLOW_O2', 'FLOW_N2', 'Setpoint_Percent_O2', 'Current_Val_Percent_O2', 'State']);

    useEffect(() => {
        const websocket = new WebSocket(`ws/${deviceId}`);

        websocket.onmessage = (event: MessageEvent) => {
            console.log("Received:", event.data);
            const json = JSON.parse(event.data);
            setData(json);

            console.log(json)

            const newData = {
                timestamp: json.Realtime_Periodic_Data.timestamp,
                InputN2_P1_bar: json.Realtime_Periodic_Data.InputN2_P1_bar,
                InputO2_P1_bar: json.Realtime_Periodic_Data.InputO2_P1_bar,
                OutputN2_P2_bar: json.Realtime_Periodic_Data.OutputN2_P2_bar,
                OutputO2_P2_bar: json.Realtime_Periodic_Data.OutputO2_P2_bar,
                FLOW_N2: json.Realtime_Periodic_Data.FLOW_N2,
                FLOW_O2: json.Realtime_Periodic_Data.FLOW_O2,
                Setpoint_Percent_O2: json.Realtime_Periodic_Data.Setpoint_Percent_O2,
                Current_Val_Percent_O2: json.Realtime_Periodic_Data.Current_Val_Percent_O2,
                State: json.Realtime_Periodic_Data.State,
            };

            setDataCache(prevData => {
                const updatedData = [...prevData, newData];
                // Keep maximum of previous 150 points (Last 5 minutes of data max)
                return updatedData.slice(-150);
            });
        };

        websocket.onerror = (event) => {
            console.error("WebSocket error:", event);
        };

        websocket.onclose = () => {
            console.log("WebSocket connection closed");
        };

        return () => {
            websocket.close();
        };
    }, []);

    useEffect(() => {
        console.log("Updated Cache: ", dataCache);
    }, [dataCache]);

    function handleTabChange(tabNumber: number): void {
        if (activeTab !== tabNumber) {
            setActiveTab(tabNumber);
        }
        if (activeTab == 1) {
            setFields(['FLOW_O2', 'FLOW_N2']);
            setShowInputPressureN2(false);
            setShowInputPressureO2(false);
            setShowOutputPressureO2(false);
            setShowOutputPressureN2(false);
            setShowSetpointO2(false);
            setShowCurrentValueO2(false);
            setShowState(false);
            setShowFlowN2(true);
            setShowFlowO2(true);
        }
        else {
            setFields(['InputO2_P1_bar', 'InputN2_P1_bar', 'OutputO2_P2_bar', 'OutputN2_P2_bar', 'Setpoint_Percent_O2', 'Current_Val_Percent_O2', 'State']);
            setShowInputPressureN2(true);
            setShowInputPressureO2(true);
            setShowOutputPressureO2(true);
            setShowOutputPressureN2(true);
            setShowSetpointO2(true);
            setShowCurrentValueO2(true);
            setShowState(true);
            setShowFlowN2(false);
            setShowFlowO2(false);
        }
    }

    function handleCheckboxChange(event: React.ChangeEvent<HTMLInputElement>): void {
        const { name, checked } = event.target;

        setFields(prevFields =>
            checked
                ? [...prevFields, name]
                : prevFields.filter(field => field !== name)
        );

        switch (name) {
            case "InputO2_P1_bar":
                setShowInputPressureO2(checked);
                break;
            case "InputN2_P1_bar":
                setShowInputPressureN2(checked);
                break;
            case "OutputO2_P2_bar":
                setShowOutputPressureO2(checked);
                break;
            case "OutputN2_P2_bar":
                setShowOutputPressureN2(checked);
                break;
            case "FLOW_O2":
                setShowFlowO2(checked);
                break;
            case "FLOW_N2":
                setShowFlowN2(checked);
                break;
            case "Setpoint_Percent_O2":
                setShowSetpointO2(checked);
                break;
            case "Current_Val_Percent_O2":
                setShowCurrentValueO2(checked);
                break;
            case "State":
                setShowState(checked);
                break;
            default:
                break;
        }
    }

    if (data === null) return <ClipLoader cssOverride={override} />;

    return (
        <div className=" overflow-auto  px-[60px]">
            <div className="bg-white border border-black-200 p-[32px] pb-[50px] w-full shadow-md">
                <HeaderBar headerText={`Real-time data - ${deviceId}`} />
                <section className="pt-5">
                    <div>
                        {data ?
                            (<div className="w-full noto-sans-regular">

                                <div className="flex justify-between border border-black-300 py-4 px-7">
                                    <div className="flex flex-col ">
                                        <span className="text-[10px]">INPUT N2 P1 BAR</span>
                                        <span className="text-[24px]">{data.Realtime_Periodic_Data.InputN2_P1_bar}</span>
                                    </div>
                                    <div className="flex flex-col ">
                                        <td className="text-[10px]">INPUT O2 P1 BAR</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.InputO2_P1_bar}</td>
                                    </div>
                                    <div className="flex flex-col ">
                                        <td className="text-[10px]">OUTPUT N2 P2 BAR</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.OutputN2_P2_bar}</td>
                                    </div>
                                    <div className="flex flex-col ">

                                        <td className="text-[10px]">OUTPUT O2 P2 BAR</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.OutputO2_P2_bar}</td>
                                    </div>
                                    <div className="flex flex-col ">

                                        <td className="text-[10px]">FLOW N2</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.FLOW_N2}</td>
                                    </div>
                                    <div className="flex flex-col ">
                                        <td className="text-[10px]">FLOW O2</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.FLOW_O2}</td>
                                    </div>
                                    <div className="flex flex-col ">

                                        <td className="text-[10px]">SETPOINT PERCENT O2</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.Setpoint_Percent_O2}</td>
                                    </div>
                                    <div className="flex flex-col ">

                                        <td className="text-[10px]">CURRENT VAL PERCENT O2</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.Current_Val_Percent_O2}</td>
                                    </div>
                                    <div className="flex flex-col ">
                                        <td className="text-[10px]">STATE</td>
                                        <td className="text-[24px]">{data.Realtime_Periodic_Data.State}</td>
                                    </div>
                                </div>

                            </div>
                            ) : (<div>No real time data sent</div>)}
                    </div>
                </section>


                {data ?
                    <div className="flex justify-between mt-[39px] pt-[40px]  w-full ">

                        <div className="w-[193px] flex-shrink-0 ">
                            <div role="tablist" className="tabs tabs-lifted">
                                <a
                                    onClick={() => handleTabChange(1)}
                                    role="tab"
                                    className={`noto-sans-bold h-10 tab ${activeTab === 1 ? "tab-active " : ""}`}
                                >
                                    Table 1
                                </a>
                                <a
                                    onClick={() => handleTabChange(2)}
                                    role="tab"
                                    className={`noto-sans-bold h-10 tab ${activeTab === 2 ? "tab-active" : ""}`}
                                >
                                    Table 2
                                </a>
                            </div>
                            {activeTab == 1 ?
                                <div className="flex flex-col h-2/3 text-xs noto-sans-regular">
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Input Pressure O2</label>
                                        <input
                                            type="checkbox"
                                            name="InputO2_P1_bar"
                                            checked={showInputPressureO2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Input Pressure N2</label>
                                        <input
                                            type="checkbox"
                                            name="InputN2_P1_bar"
                                            checked={showInputPressureN2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Output Pressure O2</label>
                                        <input
                                            type="checkbox"
                                            name="OutputO2_P2_bar"
                                            checked={showOutputPressureO2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Output Pressure N2</label>
                                        <input
                                            type="checkbox"
                                            name="OutputN2_P2_bar"
                                            checked={showOutputPressureN2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Setpoint %O2</label>
                                        <input
                                            type="checkbox"
                                            name="Setpoint_Percent_O2"
                                            checked={showSetpointO2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Current Value %O2</label>
                                        <input
                                            type="checkbox"
                                            name="Current_Val_Percent_O2"
                                            checked={showCurrentValueO2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>State</label>
                                        <input
                                            type="checkbox"
                                            name="State"
                                            checked={showState}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                </div>
                                :
                                <div className="flex flex-col h-2/3 text-xs noto-sans-regular">
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Flow O2</label>
                                        <input
                                            type="checkbox"
                                            name="FLOW_O2"
                                            checked={showFlowO2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                    <div className="flex justify-between py-3 px-2 border-b border-black-300">
                                        <label>Flow N2</label>
                                        <input
                                            type="checkbox"
                                            name="FLOW_N2"
                                            checked={showFlowN2}
                                            onChange={handleCheckboxChange}
                                        />
                                    </div>
                                </div>}
                        </div>

                        <ResponsiveContainer width="100%" height={430}>
                            <LineChart data={dataCache} margin={{}}>
                                {showInputPressureN2 && < Line type="monotone" dataKey="InputN2_P1_bar" stroke="#032cfc" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showInputPressureO2 && < Line type="monotone" dataKey="InputO2_P1_bar" stroke="#03a1fc" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showOutputPressureN2 && <Line type="monotone" dataKey="OutputN2_P2_bar" stroke="#03fcdf" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showOutputPressureO2 && <Line type="monotone" dataKey="OutputO2_P2_bar" stroke="#ad03fc" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showFlowN2 && <Line type="monotone" dataKey="FLOW_N2" stroke="#dffc03" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showFlowO2 && <Line type="monotone" dataKey="FLOW_O2" stroke="#02a63b" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showSetpointO2 && <Line type="monotone" dataKey="Setpoint_Percent_O2" stroke="#fcba03" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showCurrentValueO2 && <Line type="monotone" dataKey="Current_Val_Percent_O2" stroke="#fc0703" connectNulls={false} dot={false} isAnimationActive={false} />}
                                {showState && <Line type="monotone" dataKey="State" stroke="#e60292" connectNulls={false} dot={false} isAnimationActive={false} />}
                                <XAxis domain={[0, 150]} textAnchor={"end"} angle={-30} dataKey="timestamp" tickFormatter={(timestamp) => new Date(timestamp).toLocaleTimeString()} tick={{ fontSize: 12 }} />
                                <YAxis domain={[0, 40]} />
                                <Tooltip />
                                <Legend layout="horizontal" align="center" verticalAlign="top" wrapperStyle={{ fontSize: "12px", paddingBottom: 20 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                    : null
                }
            </div>
        </div>
    )
}

export default RealtimeInfoView;