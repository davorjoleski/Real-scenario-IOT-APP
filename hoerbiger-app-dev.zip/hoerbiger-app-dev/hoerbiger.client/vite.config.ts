import { fileURLToPath, URL } from 'node:url';

import { defineConfig } from 'vite';
import plugin from '@vitejs/plugin-react';

import { env } from 'process';



const target = env.ASPNETCORE_HTTPS_PORT ? `https://localhost:${env.ASPNETCORE_HTTPS_PORT}` :
    env.ASPNETCORE_URLS ? env.ASPNETCORE_URLS.split(';')[0] : 'https://localhost:7129';
console.log('Vite proxy target:', target);
console.log('Vite proxy web socket target:', env.SERVER_WS_URL ? env.SERVER_WS_URL : 'ws://localhost:5299')


// https://vitejs.dev/config/
export default defineConfig({
    plugins: [plugin()],
    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url))
        }
    },
    server: {
        proxy: {
            '/api': {
                target, 
                changeOrigin: true,
                secure: false
            },
            '/ws':{
                ws: true,
                target: env.SERVER_WS_URL ? env.SERVER_WS_URL : 'ws://localhost:5299',
                secure: false,
                changeOrigin: true
            }
          
            
        },
        port: 53126,
        host: '0.0.0.0'
    }
})
