using Hoerbiger.Server.Cache;
using Hoerbiger.Server.Service;
using Hoerbiger.Server.WebSocketService;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Cosmos;
using MQTTnet;
using MQTTnet.Client;
using InfluxDB.Client;
using Newtonsoft.Json.Linq;
var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddEnvironmentVariables();

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddSingleton<InfluxDBService>();
builder.Services.AddSingleton<CosmosDbService>();

builder.Services.AddSingleton<MessageRouter>();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHostedService<MqttBackgroundService>(serviceProvider =>
{
    var messageRouter = serviceProvider.GetRequiredService<MessageRouter>();
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    var mqttClient = serviceProvider.GetRequiredService<IMqttClient>();
    return new MqttBackgroundService(messageRouter, configuration, mqttClient);
});


var cosmosSettings = builder.Configuration.GetSection("AzureCosmosDb");
var cosmosClient = new CosmosClient(
    cosmosSettings["Account"],
    cosmosSettings["Key"]
);

// Register CosmosDbService with DI
builder.Services.AddSingleton(cosmosClient);

builder.Services.AddSingleton<InfluxDBClient>(serviceProvider =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    var host = configuration["InfluxDB:Host"];
    var token = configuration["InfluxDB:Token"];
    return new InfluxDBClient(host, token);
});

builder.Services.AddSingleton<MqttFactory>();

builder.Services.AddSingleton<IMqttClient>(serviceProvider =>
{
    var factory = serviceProvider.GetRequiredService<MqttFactory>();
    return factory.CreateMqttClient();
});

builder.Services.AddSingleton<SystemInfoCache>();
builder.Services.AddSingleton<SystemStatusCache>();
builder.Services.AddSingleton<WebSocketComponent>();
builder.Services.AddSingleton<MessagePublisher>();
builder.Services.AddScoped<SystemInfoService>();
builder.Services.AddSingleton<MSTeamsWorkflowService>();
builder.Services.AddSingleton<AlertsService>();
builder.Services.AddSingleton<DeviceSendStatusCache>();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

var port = app.Urls.FirstOrDefault()?.Split(':')[1];
Console.WriteLine($"WebSocket server is running on port: {app.Urls.ToString()}");

var statusCache = app.Services.GetRequiredService<SystemStatusCache>();


statusCache.StartMonitoring(10);

app.Lifetime.ApplicationStopping.Register(() =>
{
    statusCache.StopMonitoring();
});


app.UseWebSockets();

app.Use(async (context, next) =>
{
    if (context.Request.Path.StartsWithSegments("/ws"))
    {
        var webSocketComponent = context.RequestServices.GetRequiredService<WebSocketComponent>();
        await webSocketComponent.AcceptConnectionAsync(context);
    }
    else
    {
        await next(context);
    }

});


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.MapFallbackToFile("/index.html");

app.Run();