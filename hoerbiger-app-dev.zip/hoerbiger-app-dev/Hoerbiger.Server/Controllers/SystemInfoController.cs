﻿using Hoerbiger.Server.Model;
using Hoerbiger.Server.Service;
using Microsoft.AspNetCore.Mvc;

namespace Hoerbiger.Server.Controllers
{
    [Route("api/[controller]")]
    public class SystemInfoController : ControllerBase
    {
        private readonly SystemInfoService _service;

        public SystemInfoController(SystemInfoService service)
        {
            _service = service;
        }


        [HttpGet]
        [Route("")]
        public IActionResult GetAll()
        {
            var systemInfos = _service.GetAll();
            if (systemInfos == null)
            {
                
                return NotFound("SystemInfo not found.");
            }

            return Ok(systemInfos);
        }



        [HttpPost]
        [Route("add-or-update")]
        public IActionResult AddOrUpdateSystemInfo([FromQuery] string key, [FromBody] SystemInfo systemInfo)
        {
            if (string.IsNullOrWhiteSpace(key) || systemInfo == null)
            {
                return BadRequest("Key and SystemInfo are required.");
            }

            _service.AddOrUpdateSystemInfo(key, systemInfo);
            return Ok("SystemInfo added or updated successfully.");
        }


        [HttpGet]
        [Route("{key}")]
        public IActionResult GetSystemInfo(string key)
        {
            var systemInfo = _service.GetSystemInfo(key);
           if (systemInfo == null)
            {
                return NotFound("SystemInfo not found.");
            }

            return Ok(systemInfo);
        }


        [HttpDelete]
        [Route("{key}")]
        public IActionResult RemoveSystemInfo(string key)
        {
            var removed = _service.RemoveSystemInfo(key);
            if (!removed)
            {
                return NotFound("SystemInfo not found.");
            }

            return Ok("SystemInfo removed successfully.");
        }


    }
}
