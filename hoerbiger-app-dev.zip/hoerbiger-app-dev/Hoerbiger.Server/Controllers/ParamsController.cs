﻿using Hoerbiger.Server.Model;
using Hoerbiger.Server.Service;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Hoerbiger.Server.Controllers
{
    [ApiController]
    [Route("api/params")]
    public class DeviceController : ControllerBase
    {
        private readonly MessagePublisher _messagePublisher;

        public DeviceController(MessagePublisher messagePublisher)
        {
            _messagePublisher = messagePublisher;
        }

        [HttpGet("{hoeProductId}")]
        public async Task<IActionResult> GetDeviceParameters(string hoeProductId)
        {
            var requestTopic = $"{hoeProductId}/Get_Params";
            var responseTopic = $"{hoeProductId}/Params";

            try
            {
                var response = await _messagePublisher.RequestResponseAsync(requestTopic, responseTopic, "");


                return Ok(response);
            }
            catch (TimeoutException)
            {
                return StatusCode(504, new { Message = "System did not respond in time." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }

        [HttpPut("{hoeProductId}")]
        public async Task<IActionResult> SetDeviceParameters(string hoeProductId, [FromBody] Parameters parameters)
        {
            var requestTopic = $"{hoeProductId}/Set_Params";
            var responseTopic = $"{hoeProductId}/Params";

            try
            {
                var payload = JsonConvert.SerializeObject(parameters);
                var response = await _messagePublisher.RequestResponseAsync(requestTopic, responseTopic, payload);


                return Ok(response);
            }
            catch (TimeoutException)
            {
                return StatusCode(504, new { Message = "System is unreachable. Please try again." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = ex.Message });
            }
        }
    }
}
