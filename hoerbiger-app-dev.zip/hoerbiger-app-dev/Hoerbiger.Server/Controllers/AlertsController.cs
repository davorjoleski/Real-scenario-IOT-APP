﻿using Hoerbiger.Server.Model;
using Hoerbiger.Server.Service;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class AlertsController : ControllerBase
{
    private readonly AlertsService _alertsService;

    public AlertsController(AlertsService alertsService)
    {
        _alertsService = alertsService;
    }

    [HttpGet("{hoeProductId}")]
    public async Task<IActionResult> GetAlerts(string hoeProductId)
    {
        var alarms = await _alertsService.GetAlertsAsync(hoeProductId);

        Console.WriteLine($"[DEBUG] Retrieved {alarms.Count} alerts for hoeProductId {hoeProductId}");

        if (alarms == null || alarms.Count == 0)
        {
            return NotFound("No alerts found.");
        }

        return Ok(alarms);
    }

    [HttpGet("{hoeProductId}/paginated")]
    public async Task<IActionResult> GetPaginatedAlerts(string hoeProductId, [FromQuery] int pageSize = 9, [FromQuery] string? continuationToken = null)
    {
        var (alerts, deviceStatus, newToken) = await _alertsService.GetPaginatedAlertsAsync(hoeProductId, pageSize, continuationToken);

        if (alerts == null)
        {
            return NotFound("No alerts found for that device");
        }
        return Ok(new {alerts, deviceStatus, continuationToken = newToken});
    }

    [HttpGet("{hoeProductId}/latestIsRead")]
    public async Task<IActionResult> GetLatestAlertReadStatus(string hoeProductId)
    {
        var isRead = await _alertsService.GetLatestAlertReadStatusAsync(hoeProductId);

        if (isRead == null)
        {
            return NotFound("No alerts found.");
        }

        return Ok(new { isRead });
    }

    [HttpPost("{hoeProductId}/read")]
    public async Task<IActionResult> MarkAlertAsRead(string hoeProductId)
    {
        if (string.IsNullOrEmpty(hoeProductId))
        {
            return BadRequest("Invalid request. ID and systemSerial are required.");
        }

        await _alertsService.MarkAlertAsReadAsync( hoeProductId);
        return Ok(new { message = "Alert marked as read." });
    }

    [HttpGet("subscribe/{hoeProductId}")]
    public async Task Subscribe(string hoeProductId)
    {
        Response.ContentType = "text/event-stream";
        Response.Headers.Add("Cache-Control", "no-cache");
        Response.Headers.Add("Connection", "keep-alive");

        var writer = new StreamWriter(Response.Body);
        var clientId = Guid.NewGuid().ToString() + '/' + hoeProductId;
        _alertsService.AddClient(clientId, writer);
        try
        {
            await writer.FlushAsync();
            while (!HttpContext.RequestAborted.IsCancellationRequested)
            {
                await Task.Delay(1000);
            }
        }
        finally
        {
            _alertsService.RemoveClient(clientId);
        }
    }

    [HttpGet("{hoeProductId}/getAlarmStatus")]
    public async Task<IActionResult> GetAlarmStatus(string hoeProductId)
    {
        bool status = _alertsService.GetDeviceStatus(hoeProductId).CanSend;
        return Ok(status);
    }

    [HttpPatch("{hoeProductId}/toggleAlarmStatus")]
    public IActionResult ToggleAlarmStatus(string hoeProductId)
    {
        var deviceStatus = _alertsService.GetDeviceStatus(hoeProductId);
        bool newStatus = deviceStatus.switchStatus();
        _alertsService.AddOrUpdateDeviceSendStatus(hoeProductId, deviceStatus);
        return Ok(newStatus);
    }

    [HttpGet("{hoeProductId}/fetchAlertsInformation")]
    public async Task<IActionResult> GetAlertsInformation(string hoeProductId)
    {
        var alertsInformation = await _alertsService.GetDeviceInformationAsync(hoeProductId);
        Console.WriteLine($"[DEBUG] Retrieved {alertsInformation.Alerts?.Count ?? 0} alerts for hoeProductId {hoeProductId}");
        Console.WriteLine($"[DEBUG] Retrieved Status {alertsInformation.DeviceSendStatus?.CanSend} for hoeProductId {hoeProductId}");
        return Ok(alertsInformation);
    }
}
