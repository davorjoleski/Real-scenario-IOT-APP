﻿using Hoerbiger.Server.Model;
using Hoerbiger.Server.Model.Dto;
using Hoerbiger.Server.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hoerbiger.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RealTimeDataController : ControllerBase
    {

        private readonly InfluxDBService _fluxDBService;

        public RealTimeDataController(InfluxDBService influxDBService)
        {
            _fluxDBService = influxDBService;
        }

        [HttpPost("GetAll")]
        public async Task<IActionResult> GetAll([FromBody] RealtimeRequest request)
        {
            var response = await _fluxDBService.QueryAsync(request);

            return Ok(response);
        }
        
    }

}
