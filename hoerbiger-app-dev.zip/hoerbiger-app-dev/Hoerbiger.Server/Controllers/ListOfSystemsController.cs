﻿using Hoerbiger.Server.Cache;
using Hoerbiger.Server.Service;
using Microsoft.AspNetCore.Mvc;

namespace Hoerbiger.Server.Controllers
{
    [Route("api/[controller]")]
    public class ListOfSystemsController : Controller
    {
        private readonly SystemStatusCache _systemStatusService;
        public ListOfSystemsController(SystemStatusCache systemStatusService) {
            _systemStatusService = systemStatusService;
        }
        [HttpGet]
        [Route("")]
        public IActionResult GetSystems()
        {
            var systems = _systemStatusService.GetAll();
            return Ok(systems);
        }

        [HttpGet]
        [Route("{key}")]
        public IActionResult GetSystemStatus(string key)
        {
            var status = _systemStatusService.Get(key).Status;
            return Ok(status);
        }
    }
}
