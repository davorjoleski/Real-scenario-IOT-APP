﻿using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using Hoerbiger.Server.Model;

namespace Hoerbiger.Server.WebSocketService
{
    public class WebSocketComponent
    {
        private readonly ConcurrentDictionary<string, WebSocket> _clients = new();

        public void AddClient(string clientId, WebSocket webSocket)
        {
            _clients.TryAdd(clientId, webSocket);
        }

        public void RemoveClient(string clientId)
        {
            if (_clients.TryRemove(clientId, out var webSocket))
            {
                webSocket.Dispose();
            }
        }

        public async Task AcceptConnectionAsync(HttpContext context)
        {
            if (context.WebSockets.IsWebSocketRequest)
            {
                var systemId= context.Request.Path.ToString().Split('/').Last();
                var clientId = Guid.NewGuid().ToString()+"/"+systemId;
                var webSocket = await context.WebSockets.AcceptWebSocketAsync();

                AddClient(clientId, webSocket);
                Console.WriteLine($"WebSocket client connected: {clientId}");

                await HandleClientAsync(clientId, webSocket);
            }
            else
            {
                context.Response.StatusCode = 400; // Bad Request
            }
        }

        private async Task HandleClientAsync(string clientId, WebSocket webSocket)
        {
            var buffer = new byte[1024 * 4];

            while (webSocket.State == WebSocketState.Open)
            {
                try
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        Console.WriteLine($"Client disconnected: {clientId}");
                        RemoveClient(clientId);
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Connection closed", CancellationToken.None);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error handling client {clientId}: {ex.Message}");
                    RemoveClient(clientId);
                    break;
                }
            }
        }

        public async Task BroadcastMessageAsync(string message,string _systemId)
        {
            var buffer = Encoding.UTF8.GetBytes(message);

            foreach (var client in _clients)
            {
                var key=client.Key;
                var systemId=key.Split('/').Last();
                var value=client.Value;
                if (value.State == WebSocketState.Open && systemId==_systemId)
                {
                    try
                    {
                        await value.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error broadcasting message: {ex.Message}");
                    }
                }
            }
        }
    } }


