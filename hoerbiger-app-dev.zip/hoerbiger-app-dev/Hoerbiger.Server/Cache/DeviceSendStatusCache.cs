﻿using Hoerbiger.Server.Model;
using System.Collections.Concurrent;

namespace Hoerbiger.Server.Cache
{
    public class DeviceSendStatusCache
    {
        private readonly ConcurrentDictionary<String, DeviceSendStatus> _cache = new ConcurrentDictionary<String, DeviceSendStatus>();

        // Add or update an item in the cache
        public void AddOrUpdate(String key, DeviceSendStatus value)
        {
            _cache.AddOrUpdate(key, value, (existingKey, existingValue) => value);
        }

        public List<KeyValuePair<string, DeviceSendStatus>> GetAll()
        {
            return _cache.ToList();
        }

        public DeviceSendStatus Get(String key, Func<String, DeviceSendStatus> valueFactory = null)
        {

            if (_cache.TryGetValue(key, out DeviceSendStatus value))
            {
                return value;
            }

            if (valueFactory != null)
            {
                value = valueFactory(key); 
                return value;
            }

            return default;
        }

        public ICollection<String> GetDeviceIds() => _cache.Keys;

        // Remove an item from the cache
        public bool Remove(String key)
        {
            return _cache.TryRemove(key, out _);
        }

        // Clear all items in the cache
        public void Clear()
        {
            _cache.Clear();
        }
    }
}
