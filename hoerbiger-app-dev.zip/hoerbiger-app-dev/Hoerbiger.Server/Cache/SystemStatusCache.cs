﻿using Hoerbiger.Server.Model;
using System.Collections.Concurrent;

namespace Hoerbiger.Server.Cache
{
    public class SystemStatusCache
    {
        private readonly ConcurrentDictionary<String, SystemStatus> _cache = new ConcurrentDictionary<String, SystemStatus>();
        private Timer _timer;
        // Add or update an item in the cache
        public void AddOrUpdate(String key, SystemStatus value)
        {
            _cache.AddOrUpdate(key, value, (existingKey, existingValue) => value);
        }

        public List<KeyValuePair<string, SystemStatus>> GetAll()
        {
            return _cache.ToList();
        }

        public SystemStatus Get(String key, Func<String, SystemStatus> valueFactory = null)
        {
            if (_cache.TryGetValue(key, out SystemStatus value))
            {
                return value;
            }

            if (valueFactory != null)
            {
                value = valueFactory(key);
                return value;
            }

            return default;
        }

        public ICollection<String> GetSystemIds() => _cache.Keys;

        // Remove an item from the cache
        public bool Remove(String key)
        {
            return _cache.TryRemove(key, out _);
        }

        // Clear all items in the cache
        public void Clear()
        {
            _cache.Clear();
        }
        public void StartMonitoring(int intervalInSeconds = 10)
        {
            _timer = new Timer(_ =>
            {
                foreach (var entry in _cache)
                {
                    entry.Value.calculateStatus();
                    Console.WriteLine(entry.Key +": "+ entry.Value.calculateStatus());
                }
            }, null, TimeSpan.Zero, TimeSpan.FromSeconds(intervalInSeconds));
        }

        public void StopMonitoring()
        {
            _timer?.Dispose();
        }
    }

}
