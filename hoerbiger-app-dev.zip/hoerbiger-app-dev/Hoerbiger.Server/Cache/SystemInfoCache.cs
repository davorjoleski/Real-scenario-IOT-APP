﻿using Hoerbiger.Server.Model;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;

namespace Hoerbiger.Server.Cache
{
    public class SystemInfoCache
    {
        private readonly ConcurrentDictionary<String, SystemInfo> _cache = new ConcurrentDictionary<String, SystemInfo>();

        // Add or update an item in the cache
        public void AddOrUpdate(String key, SystemInfo value)
        {
            _cache.AddOrUpdate(key, value, (existingKey, existingValue) => value);
        }

        public List<KeyValuePair<string,SystemInfo>> GetAll()
        {
            return _cache.ToList();
        }

        public SystemInfo Get(String key, Func<String, SystemInfo> valueFactory = null)
        {

            if (_cache.TryGetValue(key, out SystemInfo value))
            {
                return value;
            }

            if (valueFactory != null)
            {
                value = valueFactory(key);
                //_cache.TryAdd(key, 
                return value;
            }

            return default;
        }

        public ICollection<String> GetSystemIds() => _cache.Keys;

        // Remove an item from the cache
        public bool Remove(String key)
        {
            return _cache.TryRemove(key, out _);
        }

        // Clear all items in the cache
        public void Clear()
        {
            _cache.Clear();
        }
    }
}
