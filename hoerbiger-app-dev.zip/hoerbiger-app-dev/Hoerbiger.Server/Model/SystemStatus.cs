﻿using Newtonsoft.Json;

namespace Hoerbiger.Server.Model
{
    public class SystemStatus
    {
        public DateTime? LastMessage { get; set; } = null;

        public bool Status { get; set; }
        public SystemStatus(bool _status) 
        { 
            Status = _status;
        }
        public bool calculateStatus()
        {
            if(DateTime.Now - LastMessage > TimeSpan.FromSeconds(10))
                Status = false;
            else Status = true;
            return Status;
        }

    }
}
