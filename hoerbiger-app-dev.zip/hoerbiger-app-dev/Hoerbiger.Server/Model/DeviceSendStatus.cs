﻿namespace Hoerbiger.Server.Model
{
    public class DeviceSendStatus
    {
        public bool CanSend { get; set; } = true;

        public DeviceSendStatus() {
            CanSend = true;
        }

        public DeviceSendStatus(bool _status)
        {
            CanSend = _status;
        }

        public bool switchStatus() {
            return CanSend = !CanSend;
        }

        public bool setStatus(bool _newStatus)
        {
            return CanSend = _newStatus;
        }
    }
}
