﻿using Newtonsoft.Json;

namespace Hoerbiger.Server.Model
{

    public class RealTimeData
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("HOE_product_ID")]
        public string HOEProductID { get; set; }
        
        [JsonProperty("INPUTN2_P1_bar")]
        public double InputPressureN2 { get; set; }

        [JsonProperty("OutputN2_P2_bar")]
        public double OutputPressureN2 { get; set; }

        [JsonProperty("InputO2_P1_bar")]
        public double InputPressureO2 { get; set; }

        [JsonProperty("OutputO2_P2_bar")]
        public double OutputPressureO2 { get; set; }

        [JsonProperty("FLOW_O2")]
        public double FlowO2 { get; set; }

        [JsonProperty("FLOW_N2")]
        public double FlowN2 { get; set; }

        [JsonProperty("Setpodouble_Percent_O2")]
        public double SetpointPercentO2 { get; set; }

        [JsonProperty("Current_Val_Percent_O2")]
        public double CurrentValPercentO2 { get; set; }

        [JsonProperty("State")]
        public double State { get; set; }

        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; }
    }
}
