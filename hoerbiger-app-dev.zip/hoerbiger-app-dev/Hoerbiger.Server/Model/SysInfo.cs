﻿using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Hoerbiger.Server.Model
{

    public class SysInfoRoot
    {
        [JsonProperty("System-Info")]
        public SystemInfo SystemInfo { get; set; }
    }


    public class SystemInfo
    {
        [JsonProperty("TS_System")]
        public TSSystem TSSystem { get; set; }

        [JsonProperty("TS_Board_CU")]
        public TSBoard TSBoardCU { get; set; }

        [JsonProperty("TS_Board_HMI")]
        public TSBoard TSBoardHMI { get; set; }
    }

    public class TSSystem
    {
        [JsonProperty("Base_version")]
        public string BaseVersion { get; set; }

        [JsonProperty("Sub_version")]
        public string SubVersion { get; set; }

        [JsonProperty("Bus_comm_version")]
        public string BusCommVersion { get; set; }

        [JsonProperty("Secret_version")]
        public string SecretVersion { get; set; }

        [JsonProperty("Standalone_version")]
        public string StandaloneVersion { get; set; }
    }

    public class TSBoard
    {
        [JsonProperty("Base_version")]
        public string BaseVersion { get; set; }

        [JsonProperty("Sub_version")]
        public string SubVersion { get; set; }

        [JsonProperty("Production_week")]
        public int ProductionWeek { get; set; }

        [JsonProperty("Production_year")]
        public int ProductionYear { get; set; }

        [JsonProperty("Manufacturer_name")]
        public string ManufacturerName { get; set; }
    }


}

