﻿using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Hoerbiger.Server.Model
{
    public class Parameters
    {
        [JsonPropertyName("CP_VERSION_MINOR")]
        public int CP_VERSION_MINOR { get; set; }
        [JsonPropertyName("CP_PARAMETER_COUNT")]
        public int CP_PARAMETER_COUNT { get; set; }
        [JsonPropertyName("CPF_PISTON_O2_POSITION_X")]
        public float CPF_PISTON_O2_POSITION_X { get; set; }
        [JsonPropertyName("CPF_PISTON_O2_POSITION_Y")]
        public float CPF_PISTON_O2_POSITION_Y { get; set; }
        [JsonPropertyName("CPF_PISTON_N2_POSITION_X")]
        public float CPF_PISTON_N2_POSITION_X { get; set; }
        [JsonPropertyName("CPF_PISTON_N2_POSITION_Y")]
        public float CPF_PISTON_N2_POSITION_Y { get; set; }
        [JsonPropertyName("CPF_PISTON_N2_POSITION_Z")]
        public float CPF_PISTON_N2_POSITION_Z { get; set; }
        [JsonPropertyName("CPF_SETPOINT_PCTOOL_PCO2")]
        public float CPF_SETPOINT_PCTOOL_PCO2 { get; set; }
        [JsonPropertyName("CP_PRESSURE_IN_RANGE_THRESHOLD")]
        public int CP_PRESSURE_IN_RANGE_THRESHOLD { get; set; }
        [JsonPropertyName("CP_PRESSURE_IN_RANGE_INTER")]
        public int CP_PRESSURE_IN_RANGE_INTER { get; set; }
    }
}
