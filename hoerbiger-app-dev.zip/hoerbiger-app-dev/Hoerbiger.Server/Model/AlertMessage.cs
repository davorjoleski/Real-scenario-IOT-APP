﻿namespace Hoerbiger.Server.Model
{
    public class AlertMessage
    {
        public string Serial_number_system { get; set; }
        public string Serial_number_IOT { get; set; }
        public string Diagnostic_ID { get; set; }
    }

    public class AlertMqtt
    {
        public AlertMessage Alert { get; set; }

    }
}
