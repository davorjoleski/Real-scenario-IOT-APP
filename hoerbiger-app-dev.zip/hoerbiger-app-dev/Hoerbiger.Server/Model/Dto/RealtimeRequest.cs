﻿namespace Hoerbiger.Server.Model.Dto
{
    public class RealtimeRequest
    {
        public List<string> Fields { get; set; }
        public string Function { get; set; }
        public string DeviceId { get; set; }
        public string Timestamp { get; set; }
        public DateTime startRange { get; set; }
        public DateTime stopRange { get; set; }

    }
}
