﻿namespace Hoerbiger.Server.Model.Dto
{
    public class DeviceInfoResponse
    {
        public List<AlertMessage> Alerts { get; set; }
        public DeviceSendStatus DeviceSendStatus { get; set; }
        public DeviceInfoResponse(List<AlertMessage> _alerts, DeviceSendStatus _deviceSendStatus)
        {
            Alerts = _alerts;
            DeviceSendStatus = _deviceSendStatus;
        }
    }
}
