﻿namespace Hoerbiger.Server.Model.Dto
{
    public class AlertMessage
    {
        public string id { get; set; }
        public string alertId { get; set; }
        public string Serial_number_system { get; set; }
        public string Serial_number_IOT { get; set; }
        public string Diagnostic_ID { get; set; }
        public string HOE_product_ID { get; set; }
        public bool IsRead { get; set; } = false;
        public DateTime Timestamp { get; set; }
    }
}
