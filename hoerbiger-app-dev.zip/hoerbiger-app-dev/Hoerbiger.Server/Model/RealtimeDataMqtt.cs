﻿namespace Hoerbiger.Server.Model
{
    using System.Collections.Generic;

    public class RealtimePeriodicData
    {
        public double InputO2_P1_bar { get; set; }
        public double InputN2_P1_bar { get; set; }
        public double OutputO2_P2_bar { get; set; }
        public double OutputN2_P2_bar { get; set; }
        public double FLOW_O2 { get; set; }
        public double FLOW_N2 { get; set; }
        public double Setpoint_Percent_O2 { get; set; }
        public double Current_Val_Percent_O2 { get; set; }
        public double State {  get; set; }
        public DateTime timestamp { get; set; }

    }

    public class RealtimeDataMqtt
    {
        public RealtimePeriodicData Realtime_Periodic_Data { get; set; }

        
    }


}
   
