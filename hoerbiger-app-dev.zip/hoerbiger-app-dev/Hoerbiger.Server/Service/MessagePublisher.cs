﻿using Hoerbiger.Server.Model;
using MQTTnet;
using MQTTnet.Client;

namespace Hoerbiger.Server.Service
{
    public class MessagePublisher
    {
        private readonly IMqttClient _mqttClient;
        private readonly MessageRouter _messageRouter;

        public MessagePublisher(IMqttClient mqttClient, MessageRouter messageRouter)
        {
            _mqttClient = mqttClient;
            _messageRouter = messageRouter;
        }

        public async Task<Parameters> RequestResponseAsync(string requestTopic, string responseTopic, string payload, int timeoutMs = 5000)
        {
            var tcs = new TaskCompletionSource<Parameters>();

            _messageRouter.AddParamsResponseHandler(responseTopic, tcs);
            Console.WriteLine(requestTopic+" "+payload);
            await PublishAsync(requestTopic, payload);

            if (await Task.WhenAny(tcs.Task, Task.Delay(timeoutMs)) == tcs.Task)
            {
                return tcs.Task.Result;
            }
            else
            {
                await _messageRouter.RouteMessageAsync(responseTopic, null);
                throw new TimeoutException("No response received from the device.");
            }
        }
        private async Task PublishAsync(string topic, string payload)
        {
            try
            {
                var message = new MqttApplicationMessageBuilder()
                    .WithTopic(topic)
                    .WithPayload(payload)
                    .Build();

                await _mqttClient.PublishAsync(message, CancellationToken.None);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error while publishing: {ex.Message}");
            }
        }
    }
}
