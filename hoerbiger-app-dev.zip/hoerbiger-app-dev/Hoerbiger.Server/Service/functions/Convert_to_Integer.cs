﻿using Hoerbiger.Server.Model.Dto;
using Microsoft.Azure.Cosmos;

namespace Hoerbiger.Server.Service.functions
{
    public class Convert_to_Integer
    {

        private readonly Container _container;

        public Convert_to_Integer(CosmosClient cosmosClient)
        {
            _container = cosmosClient.GetContainer("alertsDB", "alerts");
        }


        public async Task<int> GetNextAlertIdAsync(string deviceId)
        {
            var query = _container.GetItemQueryIterator<int>(
                new QueryDefinition("SELECT VALUE MAX(StringToNumber(c.alertId)) FROM c where c.HOE_product_ID=@deviceId")
                    .WithParameter("@deviceId", deviceId)
            );

            int lastId = 0;
            while (query.HasMoreResults)
            {
                var response = await query.ReadNextAsync();
                lastId = response.FirstOrDefault(); // If no records, lastId will remain 0
            }

            int newId = lastId + 1;
            return newId;
        }
    }
}
