using System.Collections;
using Hoerbiger.Server.Model;
using Hoerbiger.Server.Model.Dto;
using InfluxDB.Client;
using InfluxDB.Client.Api.Domain;
using InfluxDB.Client.Core.Flux.Domain;
using InfluxDB.Client.Writes;
using Microsoft.AspNetCore.DataProtection.KeyManagement;

namespace Hoerbiger.Server.Service
{
    public class InfluxDBService
    {
        private readonly InfluxDBClient _client;

        public InfluxDBService(InfluxDBClient client)
        {
            _client = client;
        }

        public void Write(string hoeProductId, RealtimeDataMqtt realtimeData)
        {
            const string bucket = "hoerbiger";
            const string org = "Intertec";
            var point = PointData
            .Measurement("real-time")
            .Tag("HOE_product_ID", hoeProductId)
            .Field("InputN2_P1_bar", realtimeData.Realtime_Periodic_Data.InputN2_P1_bar)
            .Field("InputO2_P1_bar", realtimeData.Realtime_Periodic_Data.InputO2_P1_bar)
            .Field("OutputN2_P2_bar", realtimeData.Realtime_Periodic_Data.OutputN2_P2_bar)
            .Field("OutputO2_P2_bar", realtimeData.Realtime_Periodic_Data.OutputO2_P2_bar)
            .Field("FLOW_N2", realtimeData.Realtime_Periodic_Data.FLOW_N2)
            .Field("FLOW_O2", realtimeData.Realtime_Periodic_Data.FLOW_O2)
            .Field("Setpoint_Percent_O2", realtimeData.Realtime_Periodic_Data.Setpoint_Percent_O2)
            .Field("Current_Val_Percent_O2", realtimeData.Realtime_Periodic_Data.Current_Val_Percent_O2)
            .Field("State", realtimeData.Realtime_Periodic_Data.State)
            .Timestamp(realtimeData.Realtime_Periodic_Data.timestamp, WritePrecision.Ns);

            using (var writeApi = _client.GetWriteApi())
            {
                writeApi.WritePoint(point,bucket, org);
            }

        }

        public async Task<IEnumerable<object>> QueryAsync(RealtimeRequest request)
        {
            string fieldsFilter = string.Join(" or ", request.Fields.Select(f => $"r[\"_field\"] == \"{f}\""));

            var minutes = Convert.ToDouble(request.Timestamp.Split("m")[0]);
            var timespan = request.stopRange - request.startRange;
            var delta = Math.Ceiling(timespan.TotalSeconds / 600);

            if (delta < 2)
            {
                delta = 2;
            }

            var query = "from(bucket: \"hoerbiger\")\r\n  " +
                "|> range(start: " + request.startRange.ToString("yyyy-MM-ddTHH:mm:ssZ") + ", stop: " + request.stopRange.ToString("yyyy-MM-ddTHH:mm:ssZ") + ")\r\n  " +
                "|> filter(fn: (r) => r[\"_measurement\"] == \"real-time\")\r\n  " +
                "|> filter(fn: (r) => r[\"HOE_product_ID\"] == \"" + request.DeviceId + "\")" +
                "|> filter(fn: (r) => " + fieldsFilter + ")" +
                "|> aggregateWindow(every:" + delta + "s, fn: " + request.Function + ", createEmpty: true)\r\n  " +
                "|> yield(name: \"\")";
            const string org = "Intertec";
            Console.WriteLine(query);
            var tables = await _client.GetQueryApi().QueryAsync(query, org);
            var a = tables.SelectMany(table => table.Records);
            var list = new List<Dictionary<string, object>>(tables[0].Records.Count);
            foreach (var table in tables)
            {
                var records = table.Records;
                for (int i = 0; i < records.Count; i++)
                {
                    var values = records[i].Values;

                    if (list.Count == i)
                    {
                        list.Add(new Dictionary<string, object>());
                    }

                    if (values.TryGetValue("_time", out object time) && values.TryGetValue("_value", out object value) && values.TryGetValue("_field", out object field))
                    {
                        var datetime = (NodaTime.Instant)time;
                        list[i].TryAdd("time", datetime.ToDateTimeUtc());
                        list[i].TryAdd((string)field, value);
                    }
                }
            }
            Console.WriteLine(list.ToString());
            return list;
        }
    }
}
