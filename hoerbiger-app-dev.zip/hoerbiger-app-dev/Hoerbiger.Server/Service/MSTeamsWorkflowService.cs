﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using Hoerbiger.Server.Model;

namespace Hoerbiger.Server.Service
{
    public class MSTeamsWorkflowService
    {
        private readonly string _webhookUrl = "";

        public MSTeamsWorkflowService(IConfiguration configuration)
        {
            _webhookUrl = configuration["WebhookSettings:WebhookURL"] ?? throw new ArgumentNullException("Webhook URL is not configured.");
        }

        private string generateMessage(string serial_number_system, string serial_number_iot, string diagnostic_id)
        {
            return $@"{{
              ""type"": ""message"",
              ""attachments"": [
                {{
                  ""contentType"": ""application/vnd.microsoft.card.adaptive"",
                  ""content"": {{
                    ""type"": ""AdaptiveCard"",
                    ""body"": [
                      {{
                        ""type"": ""TextBlock"",
                        ""text"": ""Alert message "",
                        ""wrap"": true
                      }},
                      {{
                        ""type"": ""TextBlock"",
                        ""text"": ""Serial number of the system : {serial_number_system}"",
                        ""wrap"": true
                      }},
                      {{
                        ""type"": ""TextBlock"",
                        ""text"": ""Serial number of the IOT module : {serial_number_iot}"",
                        ""wrap"": true
                      }},
                      {{
                        ""type"": ""TextBlock"",
                        ""text"": ""Diagnostic ID : {diagnostic_id}"",
                        ""wrap"": true
                      }}
                    ],
                    ""$schema"": ""http://adaptivecards.io/schemas/adaptive-card.json"",
                    ""version"": ""1.0""
                  }}
                }}
              ]
            }}";
        }

        public async Task<HttpResponseMessage> SendMessage(string serial_number_system, string serial_number_iot, string diagnostic_id)
        {
            Console.WriteLine($"MS Teams message triggered for {serial_number_system} - {serial_number_iot} - {diagnostic_id} at {DateTime.UtcNow:O}");
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var content = new StringContent(generateMessage(serial_number_system, serial_number_iot, diagnostic_id), System.Text.Encoding.UTF8, "application/json");
            var response = await client.PostAsync(_webhookUrl, content);
            return response;
        }
    }
}
