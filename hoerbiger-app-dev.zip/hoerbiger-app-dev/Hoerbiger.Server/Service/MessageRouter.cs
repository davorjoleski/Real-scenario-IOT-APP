﻿using Hoerbiger.Server.Cache;
using Hoerbiger.Server.Model;
using Hoerbiger.Server.WebSocketService;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Drawing.Drawing2D;
using System.Text;
using Microsoft.AspNetCore.Routing.Patterns;

namespace Hoerbiger.Server.Service
{
    public class MessageRouter
    {
        private readonly Dictionary<string, Func<string, string, Task>> _messageHandlers;

        private readonly SystemInfoCache _cache;
        private readonly SystemStatusCache _statusCache;
        private readonly ConcurrentDictionary<string, TaskCompletionSource<Parameters>> _responseParamsTasks = new();
        private readonly ConcurrentDictionary<string, TaskCompletionSource<Parameters>> AlertsTasks = new();

        private readonly WebSocketComponent _webSocketManager;

        private readonly InfluxDBService _influxDBService;

        private readonly CosmosDbService _cosmosDBService;

        private readonly MSTeamsWorkflowService _mSTeamsWorkflowService;
        private readonly AlertsService _alertsService;

        public MessageRouter(SystemInfoCache cache,
            SystemStatusCache statusCache,
            WebSocketComponent webSocketManager,
            InfluxDBService influxDBService,
            MSTeamsWorkflowService mSTeamsWorkflowService,
            AlertsService alertService,
            CosmosDbService cosmosDBService) // Inject CosmosDB

        {
            _cache = cache;
            _statusCache = statusCache;
            _webSocketManager = webSocketManager;
            _influxDBService = influxDBService;
            _mSTeamsWorkflowService = mSTeamsWorkflowService;
            _alertsService = alertService;
            _cosmosDBService = cosmosDBService; // Assign the CosmosDB service
            _messageHandlers = new Dictionary<string, Func<string, string, Task>>
            {
                { "Sys_Info_Params", HandleSystemInfoMessageAsync },
                { "Realtime_periodic_data/Data", HandleRealtimeMessageAsync},
                { "Params", HandleParamsMessageAsync},
                { "SystemFailure", HandleAlertsMessageAsync }
            };
        }

        public async Task RouteMessageAsync(string topic, byte[] payload)
        {
            try
            {
                var payloadString = Encoding.UTF8.GetString(payload);
                var baseTopic = GetTopicBase(topic);

                if (_messageHandlers.TryGetValue(baseTopic, out var handler))
                {
                    await handler(topic, payloadString);
                }
                else
                {
                    Console.WriteLine($"No handler found for topic: {topic}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing message: {ex.Message}");
            }
        }

        private string GetTopicBase(string topic)
        {
            if (topic.EndsWith("/"))
            {
                topic = topic.TrimEnd('/');
            }

            var topicParts = topic.Split('/');
            if (topicParts.Length > 1)
            {
                var baseTopic = string.Join("/", topicParts.Skip(1));
                return baseTopic;
            }

            return string.Empty;
        }

        private async Task HandleSystemInfoMessageAsync(string topic, string payload)
        {
            try
            {
                if (_alertsService.GetDeviceStatus(topic.Split("/")[0]).CanSend == true)
                {
                    var deserialized = JsonConvert.DeserializeObject<SysInfoRoot>(payload);
                    var status = new SystemStatus(true);
                    if (deserialized != null)
                    {


                        _cache.AddOrUpdate(topic.Split("/")[0], deserialized.SystemInfo);
                        _statusCache.AddOrUpdate(topic.Split("/")[0], status);
                        if (_alertsService.GetDeviceStatus(topic.Split("/")[0]) == null)
                        {
                            _alertsService.AddOrUpdateDeviceSendStatus(topic.Split("/")[0], new DeviceSendStatus());
                        }
                        Console.WriteLine(deserialized + "very nice");
                        Console.WriteLine($"Handling Params message: {deserialized.SystemInfo}");
                    }
                }
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Error deserializing System Info payload: {ex.Message}");
            }

            await Task.CompletedTask;
        }

        private async Task HandleRealtimeMessageAsync(string topic, string payload)
        {
            try
            {

                var deserialized = JsonConvert.DeserializeObject<Dictionary<string, RealtimeDataMqtt>>(payload);
                deserialized.Values.Single().Realtime_Periodic_Data.timestamp = DateTime.Now;
                Console.WriteLine(deserialized.Values.Single().Realtime_Periodic_Data.timestamp);
                var status = _statusCache.Get(topic.Split("/")[0]);
                if (status != null)
                {
                    status.LastMessage = deserialized.Values.Single().Realtime_Periodic_Data.timestamp;
                    _statusCache.AddOrUpdate(topic.Split("/")[0], status);
                }
                Console.WriteLine(deserialized.Values.Single().Realtime_Periodic_Data.Current_Val_Percent_O2 + "very nice");
                await _webSocketManager.BroadcastMessageAsync(JsonConvert.SerializeObject(deserialized.Values.Single()), deserialized.Keys.Last());//Sending data to frontend through WebSocket
                Console.WriteLine(deserialized.Keys.Single() + "very nice");
                _influxDBService.Write(deserialized.Keys.Single(), deserialized.Values.Single());

            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Error deserializing realtime data payload: {ex.Message}");
            }

            await Task.CompletedTask;
        }

        private async Task HandleParamsMessageAsync(string topic, string payload)
        {
            if (_responseParamsTasks.TryRemove(topic, out var tcs))
            {
                var parameters = JsonConvert.DeserializeObject<Parameters>(payload);
                tcs.TrySetResult(parameters);
            }
            else
            {
                Console.WriteLine($"No pending request for topic: {topic}");
            }

            await Task.CompletedTask;
        }

        public void AddParamsResponseHandler(string responseTopic, TaskCompletionSource<Parameters> tcs)
        {
            _responseParamsTasks[responseTopic] = tcs;
        }

        private async Task HandleAlertsMessageAsync(string topic, string payload)
        {
            try
            {
                string hoeProductId = topic.Split("/")[0];
                var deviceStatus = _alertsService.GetDeviceStatus(hoeProductId);
                Console.WriteLine($"Can send status: {deviceStatus.CanSend}");

                if (deviceStatus.CanSend)
                {
                    var deserialized = JsonConvert.DeserializeObject<Dictionary<string, AlertMqtt>>(payload);
                    Console.WriteLine(deserialized.Values.Single().Alert.Serial_number_system);

                    var deviceId = topic.Split("/")[0];
                    AlertMqtt alertData = deserialized.Values.Single();
                    string serial_number_system = alertData.Alert.Serial_number_system;
                    string serial_number_iot = alertData.Alert.Serial_number_IOT;
                    string diagnostic_id = alertData.Alert.Diagnostic_ID;
                    
                    await _mSTeamsWorkflowService.SendMessage(serial_number_system, serial_number_iot, diagnostic_id);
                    await _cosmosDBService.AddAlertAsync(deviceId, alertData);
                    await _alertsService.SendAlertToClients(hoeProductId, payload);
                }
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Error deserializing alert data payload: {ex.Message}");
            }
            await Task.CompletedTask;
        }

    }
}
