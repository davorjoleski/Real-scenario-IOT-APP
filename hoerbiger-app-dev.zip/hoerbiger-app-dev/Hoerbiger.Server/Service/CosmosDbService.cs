﻿using Hoerbiger.Server.Model;
using Hoerbiger.Server.Model.Dto;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Xml.Serialization;
using AlertMessage = Hoerbiger.Server.Model.Dto.AlertMessage;

using Hoerbiger.Server.Service.functions;
public class CosmosDbService
{
    private readonly CosmosClient _client;
    private readonly Container _container;
    private readonly Convert_to_Integer _convertToInteger;

    public CosmosDbService(CosmosClient cosmosClient)
    {
        _container = cosmosClient.GetContainer("alertsDB", "alerts");
        _convertToInteger = new Convert_to_Integer(cosmosClient); 

    }
    public async Task<List<AlertMessage>> GetAlertsAsync(string hoeProductId)
    {
        //var query = _container.GetItemQueryIterator<AlertMessage>( new QueryDefinition("SELECT * FROM c ORDER BY c._ts DESC"));
       var query = _container.GetItemQueryIterator<AlertMessage>(
       new QueryDefinition("SELECT * FROM c WHERE c.HOE_product_ID = @hoeProductId ORDER BY c.Timestamp DESC")
       .WithParameter("@hoeProductId", hoeProductId),
       requestOptions: new QueryRequestOptions { PartitionKey = new PartitionKey(hoeProductId) }
        );

        List<AlertMessage> results = new List<AlertMessage>();
        while (query.HasMoreResults)
        {
            var response = await query.ReadNextAsync();
            results.AddRange(response);
        }
        return results;
    }

    public async Task<(List<AlertMessage>, string)> GetPaginatedAlertsAsync(string hoeProductId, int pageSize, string continuationToken)
    {
        var queryDefinition = new QueryDefinition("SELECT * FROM c WHERE c.HOE_product_ID = @hoeProductId ORDER BY c.Timestamp DESC")
            .WithParameter("@hoeProductId", hoeProductId);

        var options = new QueryRequestOptions
        {
            PartitionKey = new PartitionKey(hoeProductId),
            MaxItemCount = pageSize
        };

        var query = _container.GetItemQueryIterator<AlertMessage>(queryDefinition, continuationToken, options);

        List<AlertMessage> results = new List<AlertMessage>();
        string newContinuationToken = null;

        if(query.HasMoreResults)
        {
            var response = await query.ReadNextAsync();
            results.AddRange(response);
            newContinuationToken = response.ContinuationToken;
        }

        return (results, newContinuationToken);
    }

    public async Task<bool?> GetLatestAlertReadStatusAsync(string hoeProductId)
    {
        var query = _container.GetItemQueryIterator<AlertMessage>(
            new QueryDefinition("SELECT * FROM c WHERE c.HOE_product_ID = @hoeProductId ORDER BY c._ts DESC OFFSET 0 LIMIT 1")
            .WithParameter("@hoeProductId", hoeProductId),
            requestOptions: new QueryRequestOptions { PartitionKey = new PartitionKey(hoeProductId) }
        );

        if (query.HasMoreResults)
        {
            var response = await query.ReadNextAsync();
            var latestAlert = response.FirstOrDefault();
            return latestAlert?.IsRead;
        }

        return null;
    }

    public async Task AddAlertAsync(string deviceId, AlertMqtt alert)
        {
            int newId = await _convertToInteger.GetNextAlertIdAsync(deviceId);
            AlertMessage alertRes = new AlertMessage()
            {
                id = Guid.NewGuid().ToString(),
                alertId = newId.ToString(),
                Serial_number_system = alert.Alert.Serial_number_system,
                Serial_number_IOT = alert.Alert.Serial_number_IOT,
                Diagnostic_ID = alert.Alert.Diagnostic_ID,
                HOE_product_ID = deviceId,
                IsRead = false,
                Timestamp = DateTime.UtcNow
            };

        try
        { 
            await _container.CreateItemAsync(alertRes, new PartitionKey(deviceId));
        }
        catch (CosmosException ex)
        {
            Console.WriteLine($"[ERROR] CosmosDB Write Error: {ex.StatusCode} - {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ERROR] General Write Error: {ex.Message}");
        }

    }

    public async Task MarkAllUnreadAlertsAsReadAsync(string hoeProductId)
    {
        var query = _container.GetItemQueryIterator<AlertMessage>(
            new QueryDefinition("SELECT * FROM c WHERE c.HOE_product_ID = @hoeProductId AND c.IsRead = false")
                .WithParameter("@hoeProductId", hoeProductId)
        );

        var alertsToUpdate = new List<AlertMessage>();

        while (query.HasMoreResults)
        {
            var response = await query.ReadNextAsync();
            alertsToUpdate.AddRange(response);
        }

        foreach (var alert in alertsToUpdate)
        {
            alert.IsRead = true;
            await _container.ReplaceItemAsync(alert, alert.id, new PartitionKey(hoeProductId));
        }
    }


}


