using System.Collections.Concurrent;
using System.Runtime.InteropServices;
using Hoerbiger.Server.Cache;
using Hoerbiger.Server.Model;
using Hoerbiger.Server.Model.Dto;
using InfluxDB.Client;
using InfluxDB.Client.Api.Domain;
using InfluxDB.Client.Writes;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using AlertMessage = Hoerbiger.Server.Model.Dto.AlertMessage;
using Microsoft.Azure.Cosmos;

namespace Hoerbiger.Server.Service;

public class AlertsService
{
    private readonly InfluxDBClient _client;
    private readonly DeviceSendStatusCache _cache;
    private readonly CosmosDbService _cosmosDbService;
    private static readonly ConcurrentDictionary<string, StreamWriter> _clients = new();

    public AlertsService(InfluxDBClient influxDBClient, DeviceSendStatusCache _deviceSendStatusCache, CosmosDbService cosmosDbService)
    {
        _client = influxDBClient;
        _cache = _deviceSendStatusCache;
        _cosmosDbService = cosmosDbService;
    }

    // Get alerts for a system serial number
    public async Task<List<AlertMessage>> GetAlertsAsync(string hoeProductId)
    {
        return await _cosmosDbService.GetAlertsAsync(hoeProductId);
    }

    public async Task<(List<AlertMessage>, DeviceSendStatus,  string)> GetPaginatedAlertsAsync(string hoeProductId, int pageSize, string continuationToken)
    {
        var (alerts, newContinuationToken) = await _cosmosDbService.GetPaginatedAlertsAsync(hoeProductId, pageSize, continuationToken);
        DeviceSendStatus deviceStatus = _cache.Get(hoeProductId, _ => new DeviceSendStatus(true));
        return (alerts, deviceStatus, newContinuationToken);
    }

    public async Task<DeviceInfoResponse> GetDeviceInformationAsync(string hoeProductId)
    {
        List<AlertMessage> alerts = await _cosmosDbService.GetAlertsAsync(hoeProductId);
        DeviceSendStatus deviceStatus = _cache.Get(hoeProductId, _ => new DeviceSendStatus(true));
        var response = new DeviceInfoResponse(alerts, deviceStatus);
        return response;
    }

    //Mark_as_Read
    public async Task<bool?> GetLatestAlertReadStatusAsync(string hoeProductId)
    {
        return await _cosmosDbService.GetLatestAlertReadStatusAsync(hoeProductId);
    }

    public async Task MarkAlertAsReadAsync(string hoeProductId)
    {
        await _cosmosDbService.MarkAllUnreadAlertsAsReadAsync(hoeProductId);
    }

    public async Task SendAlertToClients(string hoeProductId, string alertMessage)
    {
        foreach (var client in _clients)
        {
            if (client.Key.Split("/")[1] == hoeProductId)
            {
                await client.Value.WriteLineAsync($"data: New Alert!\n");
                await client.Value.FlushAsync();
            }
        }
        
    }

    public void AddClient(string clientId, StreamWriter writer)
    {
        _clients.TryAdd(clientId, writer);
    }

    public void RemoveClient(string clientId)
    {
        if (_clients.TryRemove(clientId, out var writer))
        {
            writer.DisposeAsync();
        }
    }

    public void AddOrUpdateDeviceSendStatus(string key, DeviceSendStatus deviceSendStatus)
    {
        _cache.AddOrUpdate(key, deviceSendStatus);
    }
    public List<KeyValuePair<string, DeviceSendStatus>> GetAll()
    {
        return _cache.GetAll();
    }

    public DeviceSendStatus GetDeviceStatus(string key)
    {
        return _cache.Get(key, _ => new DeviceSendStatus(true));
    }

    public bool RemoveDeviceStatus(string key)
    {
        return _cache.Remove(key);
    }

    public IEnumerable<string> GetDeviceIds() => _cache.GetDeviceIds();

    public void ClearCache()
    {
        _cache.Clear();
    }
}