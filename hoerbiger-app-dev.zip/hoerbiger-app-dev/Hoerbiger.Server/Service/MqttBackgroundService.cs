﻿

using System.Collections;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Hoerbiger.Server.Cache;
using Hoerbiger.Server.Model;
using Microsoft.AspNetCore.Builder;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Formatter;
using MQTTnet.Server;
using Newtonsoft.Json;

namespace Hoerbiger.Server.Service
{
    public class MqttBackgroundService : BackgroundService
    {
        private readonly IMqttClient _mqttClient;
        private readonly MqttClientOptions _options;
        private readonly MessageRouter _messageRouter;

        public MqttBackgroundService(MessageRouter messageRouter, IConfiguration configuration, IMqttClient mqttClient)
        {
            var host = configuration["MqttClient:host"];
            var port = Convert.ToInt32(configuration["MqttClient:port"]);
            var certFilePath = configuration["MqttClient:certFilePath"];
            var keyFilePath = configuration["MqttClient:keyFilePath"];
            var clientId = configuration["MqttClient:clientId"];
            var username = configuration["MqttClient:username"];
            var password = configuration["MqttClient:password"];

            var certificateCollection= new X509Certificate2Collection();
            
            if (certFilePath.EndsWith(".pem"))
            {
                var certificate = X509Certificate2.CreateFromPemFile(certFilePath, keyFilePath)
                    .Export(X509ContentType.Pkcs12);
                certificateCollection.Import(certificate);
            }

            if (certFilePath.EndsWith(".p12") || certFilePath.EndsWith(".pfx")) {
                var bytes = File.ReadAllBytes(certFilePath);
                var cert = new X509Certificate2(bytes);
                certificateCollection.Add(cert);
            }

            
            var tlsOptions = new MqttClientTlsOptionsBuilder()
                .WithClientCertificates(certificateCollection)
                .UseTls(true)
                .Build();

            _options = new MqttClientOptionsBuilder()
               .WithClientId(clientId)
               .WithTcpServer(host, port)
               .WithCredentials(username, password)
               .WithTlsOptions(tlsOptions)
               .WithKeepAlivePeriod(TimeSpan.FromSeconds(60))
               .WithCleanSession(false)
               .Build();

            _messageRouter = messageRouter;
            _mqttClient = mqttClient;



        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {

            

            await _mqttClient.ConnectAsync(_options, CancellationToken.None);
            await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/Realtime_periodic_data/Data/").Build());
            await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/Sys_Info_Params").Build());
            await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/Params").Build());
            await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/SystemFailure").Build());
            _mqttClient.DisconnectedAsync += async e =>
            {
                if (e.ClientWasConnected)
                {
                    Console.WriteLine("Server reconnects with broker");
                    await _mqttClient.ConnectAsync(_mqttClient.Options);
                    await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/Realtime_periodic_data/Data/").Build());
                    await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/Sys_Info_Params").Build());
                    await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/Params").Build());
                    await _mqttClient.SubscribeAsync(new MqttTopicFilterBuilder().WithTopic("+/SystemFailure").Build());
                }
            };
            _mqttClient.ApplicationMessageReceivedAsync += ea =>
            {
                ea.AutoAcknowledge = false;

                async Task ProcessAsync()
                {
                    await Task.Delay(1000);


                    await _messageRouter.RouteMessageAsync(ea.ApplicationMessage.Topic, ea.ApplicationMessage.Payload);


                }

                _ = Task.Run(ProcessAsync);

                return Task.CompletedTask;
            };
        }

    }

}
