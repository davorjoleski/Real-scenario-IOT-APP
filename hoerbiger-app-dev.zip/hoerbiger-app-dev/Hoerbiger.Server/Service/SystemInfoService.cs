﻿using System.Runtime.InteropServices;
using Hoerbiger.Server.Cache;
using Hoerbiger.Server.Model;

namespace Hoerbiger.Server.Service
{
    public class SystemInfoService
    {
        private readonly SystemInfoCache _cache;

        public SystemInfoService(SystemInfoCache cache)
        {
            _cache = cache;
        }

        public void AddOrUpdateSystemInfo(string key, SystemInfo systemInfo)
        {
            _cache.AddOrUpdate(key, systemInfo);
        }


        public List<KeyValuePair<string,SystemInfo>> GetAll()
        {
            return _cache.GetAll();
        }

        public SystemInfo GetSystemInfo(string key)
        {
            return _cache.Get(key, _ => null); // Returns null if not found
        }

        public bool RemoveSystemInfo(string key)
        {
            return _cache.Remove(key);
        }

        public IEnumerable<string> GetSystemIds() => _cache.GetSystemIds();

        public void ClearCache()
        {
            _cache.Clear();
        }
    }
}
